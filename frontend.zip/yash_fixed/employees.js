/* =====================================================
   employees.js  – Full CRUD for Employee Management
   ===================================================== */

const STORAGE_KEY = 'inv_employees';
const PAGE_SIZE_KEY = 'inv_settings';
let employees = [];
let filtered = [];
let editId = null;
let deleteId = null;
let currentPage = 1;
let sortCol = 'name';
let sortDir = 'asc';

/* ─── Avatar colour pool ─── */
const AVATAR_COLORS = [
  '#0b3d91','#2f9e44','#e5533d','#7c3aed','#0891b2',
  '#d97706','#db2777','#059669','#6366f1','#dc2626'
];
function avatarColor(name){
  let h = 0;
  for(let c of name) h = (h * 31 + c.charCodeAt(0)) & 0xffffffff;
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}
function initials(name){
  return name.trim().split(/\s+/).map(w=>w[0]).join('').toUpperCase().slice(0,2);
}

/* ─── Load / Save ─── */
function load(){
  try { employees = JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch(e){ employees = []; }
  /* no seed data */
}
function save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(employees)); }

function seedDemo(){ /* no seed – start empty */ }

/* ─── Helpers ─── */
function pageSize(){
  try {
    const s = JSON.parse(localStorage.getItem(PAGE_SIZE_KEY));
    return (s && s.pageSize) ? parseInt(s.pageSize) : 8;
  } catch(e){ return 8; }
}
function nextId(){
  const nums = employees.map(e=>parseInt(e.id.replace('EMP-',''))||0);
  return 'EMP-' + String((nums.length ? Math.max(...nums) : 0) + 1).padStart(3,'0');
}
function showToast(msg, type='success'){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast ' + type;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2800);
}
function statusClass(s){
  if(s==='Active')   return 'active';
  if(s==='On Leave') return 'on-leave';
  return 'inactive';
}

/* ─── Stats ─── */
function updateStats(){
  document.getElementById('statTotal').textContent  = employees.length;
  document.getElementById('statActive').textContent = employees.filter(e=>e.status==='Active').length;
  document.getElementById('statLeave').textContent  = employees.filter(e=>e.status==='On Leave').length;
  const depts = new Set(employees.map(e=>e.department).filter(Boolean));
  document.getElementById('statDepts').textContent  = depts.size;
}

/* ─── Dept filter populate ─── */
function populateDeptFilter(){
  const sel = document.getElementById('filterDept');
  const depts = [...new Set(employees.map(e=>e.department).filter(Boolean))].sort();
  const cur = sel.value;
  sel.innerHTML = '<option value="">All Departments</option>';
  depts.forEach(d=>{ const o=document.createElement('option'); o.value=d; o.textContent=d; sel.appendChild(o); });
  sel.value = cur;
}

/* ─── Filter + Sort ─── */
function applyFilters(){
  const q    = document.getElementById('searchInput').value.toLowerCase();
  const role = document.getElementById('filterRole').value;
  const dept = document.getElementById('filterDept').value;
  const st   = document.getElementById('filterStatus').value;

  filtered = employees.filter(e=>{
    const match = !q || e.name.toLowerCase().includes(q) || e.id.toLowerCase().includes(q)
                     || (e.role||'').toLowerCase().includes(q)
                     || (e.department||'').toLowerCase().includes(q)
                     || (e.email||'').toLowerCase().includes(q)
                     || (e.phone||'').toLowerCase().includes(q);
    const matchRole = !role || e.role === role;
    const matchDept = !dept || e.department === dept;
    const matchSt   = !st   || e.status === st;
    return match && matchRole && matchDept && matchSt;
  });

  filtered.sort((a,b)=>{
    let va = (a[sortCol]||'').toString().toLowerCase();
    let vb = (b[sortCol]||'').toString().toLowerCase();
    if(sortCol==='salary'){ va=parseFloat(a.salary)||0; vb=parseFloat(b.salary)||0; }
    if(va<vb) return sortDir==='asc'?-1:1;
    if(va>vb) return sortDir==='asc'?1:-1;
    return 0;
  });

  document.getElementById('resultCount').textContent = filtered.length + ' employee' + (filtered.length!==1?'s':'') + ' found';
  currentPage = 1;
  render();
}

/* ─── Render ─── */
function render(){
  const mode = document.getElementById('viewMode').value;
  document.getElementById('tableView').style.display = mode==='table' ? '' : 'none';
  document.getElementById('gridView').style.display  = mode==='grid'  ? '' : 'none';
  if(mode==='table') renderTable();
  else renderGrid();
}

function renderTable(){
  const ps = pageSize();
  const start = (currentPage-1)*ps;
  const page  = filtered.slice(start, start+ps);
  const tbody = document.getElementById('empTbody');

  tbody.innerHTML = page.map(e=>`
    <tr>
      <td>
        <div class="emp-name-cell">
          <div class="emp-avatar" style="background:${avatarColor(e.name)}">${initials(e.name)}</div>
          <div>
            <strong>${e.name}</strong>
            <span class="emp-sub">${e.email||'—'}</span>
          </div>
        </div>
      </td>
      <td style="font-family:monospace;font-size:13px;color:#6b7280">${e.id}</td>
      <td><span class="role-pill">${e.role||'—'}</span></td>
      <td>${e.department||'—'}</td>
      <td style="font-size:13px">${e.phone||'—'}</td>
      <td style="font-size:13px">${fmtDate(e.joinDate)}</td>
      <td><span class="tag ${statusClass(e.status)}">${e.status}</span></td>
      <td>
        <button class="act-btn btn-view"   onclick="openViewModal('${e.id}')">👁 View</button>
        <button class="act-btn btn-edit"   onclick="openEditModal('${e.id}')">✏️ Edit</button>
        <button class="act-btn btn-delete" onclick="openDeleteModal('${e.id}')">🗑</button>
      </td>
    </tr>
  `).join('');

  renderPagination('pagination', ps);
  updateSortHeaders();
}

function renderGrid(){
  const ps = pageSize();
  const start = (currentPage-1)*ps;
  const page  = filtered.slice(start, start+ps);
  const grid  = document.getElementById('empGrid');

  grid.innerHTML = page.map(e=>`
    <div class="emp-card" onclick="openViewModal('${e.id}')">
      <div class="emp-card-header">
        <div class="emp-card-avatar" style="background:linear-gradient(135deg,${avatarColor(e.name)},#4fa3ff)">${initials(e.name)}</div>
        <div>
          <div class="emp-card-name">${e.name}</div>
          <div class="emp-card-id">${e.id}</div>
        </div>
      </div>
      <div class="emp-card-info"><span>💼</span> <span class="role-pill">${e.role||'—'}</span></div>
      <div class="emp-card-info"><span>🏢</span> ${e.department||'—'}</div>
      <div class="emp-card-info"><span>📞</span> ${e.phone||'—'}</div>
      <div class="emp-card-info"><span>📅</span> Joined ${fmtDate(e.joinDate)}</div>
      <div class="emp-card-footer">
        <span class="tag ${statusClass(e.status)}">${e.status}</span>
        <div class="emp-card-actions" onclick="event.stopPropagation()">
          <button class="act-btn btn-edit"   onclick="openEditModal('${e.id}')">✏️</button>
          <button class="act-btn btn-delete" onclick="openDeleteModal('${e.id}')">🗑</button>
        </div>
      </div>
    </div>
  `).join('');

  renderPagination('paginationGrid', ps);
}

function renderPagination(id, ps){
  const total = Math.ceil(filtered.length / ps);
  const pg = document.getElementById(id);
  if(total<=1){ pg.innerHTML=''; return; }
  let html = '';
  for(let i=1;i<=total;i++){
    html += `<button class="pg-btn${i===currentPage?' active':''}" onclick="goPage(${i})">${i}</button>`;
  }
  pg.innerHTML = html;
}

function goPage(p){ currentPage=p; render(); window.scrollTo({top:0,behavior:'smooth'}); }

function updateSortHeaders(){
  document.querySelectorAll('#empTable th.sortable').forEach(th=>{
    th.classList.remove('asc','desc');
    if(th.dataset.col===sortCol) th.classList.add(sortDir);
  });
}

/* ─── Date format ─── */
function fmtDate(d){
  if(!d) return '—';
  const dt = new Date(d);
  return dt.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});
}

/* ─── Sorting ─── */
document.addEventListener('DOMContentLoaded', ()=>{
  document.querySelectorAll('#empTable th.sortable').forEach(th=>{
    th.addEventListener('click',()=>{
      if(sortCol===th.dataset.col) sortDir = sortDir==='asc'?'desc':'asc';
      else { sortCol=th.dataset.col; sortDir='asc'; }
      applyFilters();
    });
  });

  document.getElementById('searchInput').addEventListener('input', applyFilters);
  document.getElementById('filterRole').addEventListener('change', applyFilters);
  document.getElementById('filterDept').addEventListener('change', applyFilters);
  document.getElementById('filterStatus').addEventListener('change', applyFilters);
  document.getElementById('viewMode').addEventListener('change', ()=>{ currentPage=1; render(); });

  // Auto switch to card view on mobile
  if(window.innerWidth <= 700){
    document.getElementById('viewMode').value = 'grid';
  }

  load();
  populateDeptFilter();
  updateStats();
  applyFilters();
});

/* ─── Filter shortcuts ─── */
function filterByAll(){ document.getElementById('filterStatus').value=''; applyFilters(); }
function filterByStatus(s){ document.getElementById('filterStatus').value=s; applyFilters(); }

/* ─── ADD / EDIT Modal ─── */
function openAddModal(){
  editId = null;
  document.getElementById('modalTitle').textContent = 'Add Employee';
  document.getElementById('saveBtn').textContent    = 'Save Employee';
  clearForm();
  document.getElementById('fEmpId').value = nextId();
  document.getElementById('empModal').style.display = 'flex';
}
function openEditModal(id){
  const e = employees.find(x=>x.id===id);
  if(!e) return;
  editId = id;
  document.getElementById('modalTitle').textContent = 'Edit Employee';
  document.getElementById('saveBtn').textContent    = 'Update Employee';
  document.getElementById('fEmpId').value      = e.id;
  document.getElementById('fName').value       = e.name;
  document.getElementById('fRole').value       = e.role||'';
  document.getElementById('fDept').value       = e.department||'';
  document.getElementById('fPhone').value      = e.phone||'';
  document.getElementById('fEmail').value      = e.email||'';
  document.getElementById('fJoinDate').value   = e.joinDate||'';
  document.getElementById('fStatus').value     = e.status||'Active';
  document.getElementById('fSalary').value     = e.salary||'';
  document.getElementById('fShift').value      = e.shift||'';
  document.getElementById('fEmergency').value  = e.emergency||'';
  document.getElementById('fZone').value       = e.zone||'';
  document.getElementById('fAddress').value    = e.address||'';
  document.getElementById('fNotes').value      = e.notes||'';
  document.getElementById('formError').textContent = '';
  document.getElementById('empModal').style.display = 'flex';
}
function closeModal(){ document.getElementById('empModal').style.display='none'; }

function clearForm(){
  ['fName','fPhone','fEmail','fJoinDate','fSalary','fShift','fEmergency','fZone','fAddress','fNotes']
    .forEach(id=>{ document.getElementById(id).value=''; });
  document.getElementById('fRole').value   = '';
  document.getElementById('fDept').value   = '';
  document.getElementById('fStatus').value = 'Active';
  document.getElementById('formError').textContent = '';
}

function saveEmployee(){
  const name     = document.getElementById('fName').value.trim();
  const role     = document.getElementById('fRole').value;
  const dept     = document.getElementById('fDept').value;
  const phone    = document.getElementById('fPhone').value.trim();
  const joinDate = document.getElementById('fJoinDate').value;

  if(!name)     { document.getElementById('formError').textContent='Name is required.'; return; }
  if(!role)     { document.getElementById('formError').textContent='Role is required.'; return; }
  if(!dept)     { document.getElementById('formError').textContent='Department is required.'; return; }
  if(!phone)    { document.getElementById('formError').textContent='Phone number is required.'; return; }
  if(!joinDate) { document.getElementById('formError').textContent='Join date is required.'; return; }

  const record = {
    id:        editId || document.getElementById('fEmpId').value,
    name,
    role,
    department: dept,
    phone,
    email:     document.getElementById('fEmail').value.trim(),
    joinDate,
    status:    document.getElementById('fStatus').value,
    salary:    parseFloat(document.getElementById('fSalary').value)||0,
    shift:     document.getElementById('fShift').value,
    emergency: document.getElementById('fEmergency').value.trim(),
    zone:      document.getElementById('fZone').value.trim(),
    address:   document.getElementById('fAddress').value.trim(),
    notes:     document.getElementById('fNotes').value.trim(),
  };

  if(editId){
    const idx = employees.findIndex(e=>e.id===editId);
    if(idx>-1) employees[idx] = record;
    showToast('Employee updated ✓');
  } else {
    employees.push(record);
    showToast('Employee added ✓');
  }

  save();
  closeModal();
  populateDeptFilter();
  updateStats();
  applyFilters();
}

/* ─── View Detail Modal ─── */
function openViewModal(id){
  const e = employees.find(x=>x.id===id);
  if(!e) return;

  const body = document.getElementById('viewModalBody');
  body.innerHTML = `
    <div class="emp-detail-header">
      <div class="emp-detail-avatar" style="background:linear-gradient(135deg,${avatarColor(e.name)},#4fa3ff)">${initials(e.name)}</div>
      <div class="emp-detail-title">
        <h3>${e.name}</h3>
        <p>${e.role||'—'} &nbsp;·&nbsp; ${e.department||'—'}</p>
        <span class="tag ${statusClass(e.status)}" style="margin-top:6px;display:inline-block">${e.status}</span>
      </div>
    </div>
    <div class="detail-grid">
      <div class="detail-item"><label>Employee ID</label><span style="font-family:monospace">${e.id}</span></div>
      <div class="detail-item"><label>Join Date</label><span>${fmtDate(e.joinDate)}</span></div>
      <div class="detail-item"><label>Phone</label><span>${e.phone||'—'}</span></div>
      <div class="detail-item"><label>Email</label><span>${e.email||'—'}</span></div>
      <div class="detail-item"><label>Shift</label><span>${e.shift||'—'}</span></div>
      <div class="detail-item"><label>Salary</label><span>${e.salary ? '₹ ' + Number(e.salary).toLocaleString('en-IN') + ' / mo' : '—'}</span></div>
      <div class="detail-item"><label>Warehouse Zone</label><span>${e.zone||'—'}</span></div>
      <div class="detail-item"><label>Emergency Contact</label><span>${e.emergency||'—'}</span></div>
      <div class="detail-item full-width"><label>Address</label><span>${e.address||'—'}</span></div>
      <div class="detail-item full-width"><label>Notes</label><span>${e.notes||'—'}</span></div>
    </div>
  `;

  document.getElementById('viewEditBtn').onclick = ()=>{ closeViewModal(); openEditModal(id); };
  document.getElementById('viewModal').style.display = 'flex';
}
function closeViewModal(){ document.getElementById('viewModal').style.display='none'; }

/* ─── Delete Modal ─── */
function openDeleteModal(id){
  const e = employees.find(x=>x.id===id);
  if(!e) return;
  deleteId = id;
  document.getElementById('deleteMsg').textContent = `Are you sure you want to remove ${e.name} (${e.id})? This cannot be undone.`;
  document.getElementById('confirmDeleteBtn').onclick = confirmDelete;
  document.getElementById('deleteModal').style.display = 'flex';
}
function closeDeleteModal(){ document.getElementById('deleteModal').style.display='none'; deleteId=null; }
function confirmDelete(){
  if(!deleteId) return;
  employees = employees.filter(e=>e.id!==deleteId);
  save();
  closeDeleteModal();
  populateDeptFilter();
  updateStats();
  applyFilters();
  showToast('Employee removed.', 'error');
}
