/* ============================================================
   profile.js – Personal profile, password change, stats
   ============================================================ */

const PROFILE_KEY = "inv_profile";

window.addEventListener("DOMContentLoaded", () => {
  loadProfile();
  renderActivity();
  loadStats();
  recordLogin();

  document.getElementById("logoutBtn").onclick = function () {
    alert("Logging out..."); window.location.href = "login.html";
  };
});

/* ---- Load saved profile ---- */
function loadProfile() {
  const raw = localStorage.getItem(PROFILE_KEY);
  if (!raw) return;
  const p = JSON.parse(raw);

  if (p.name)   { document.getElementById("pName").value = p.name;   updateBanner("bannerName", p.name); }
  if (p.email)  { document.getElementById("pEmail").value = p.email; updateBanner("bannerEmail", p.email); }
  if (p.phone)  document.getElementById("pPhone").value  = p.phone;
  if (p.dept)   document.getElementById("pDept").value   = p.dept;
  if (p.role)   { document.getElementById("pRole").value = p.role;   updateBanner("bannerRole", p.role); }
  if (p.avatar) document.getElementById("profileAvatar").src = p.avatar;
}

/* ---- Save profile ---- */
function saveProfile() {
  const name  = document.getElementById("pName").value.trim();
  const email = document.getElementById("pEmail").value.trim();
  const errEl = document.getElementById("profileError");

  if (!name)  { errEl.textContent = "Full name is required.";     return; }
  if (!email) { errEl.textContent = "Email address is required."; return; }
  errEl.textContent = "";

  const profile = {
    name,
    email,
    phone:  document.getElementById("pPhone").value.trim(),
    dept:   document.getElementById("pDept").value.trim(),
    role:   document.getElementById("pRole").value.trim(),
    avatar: document.getElementById("profileAvatar").src,
  };

  localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));

  updateBanner("bannerName",  name);
  updateBanner("bannerEmail", email);

  toast("Profile saved successfully!", "success");
}

function updateBanner(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

/* ---- Change password ---- */
function changePassword() {
  const curr  = document.getElementById("pCurrPwd").value;
  const nw    = document.getElementById("pNewPwd").value;
  const conf  = document.getElementById("pConfPwd").value;
  const errEl = document.getElementById("pwdError");

  if (!curr)       { errEl.textContent = "Current password is required.";          return; }
  if (nw.length < 6) { errEl.textContent = "New password must be at least 6 characters."; return; }
  if (nw !== conf) { errEl.textContent = "Passwords do not match.";                return; }

  errEl.textContent = "";
  document.getElementById("pCurrPwd").value = "";
  document.getElementById("pNewPwd").value  = "";
  document.getElementById("pConfPwd").value = "";

  toast("Password updated successfully!", "success");
}

/* ---- Change avatar ---- */
function changeAvatar(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById("profileAvatar").src = e.target.result;

    const raw = localStorage.getItem(PROFILE_KEY);
    const p   = raw ? JSON.parse(raw) : {};
    p.avatar  = e.target.result;
    localStorage.setItem(PROFILE_KEY, JSON.stringify(p));

    toast("Profile photo updated!", "success");
  };
  reader.readAsDataURL(file);
}

/* ---- Recent activity – built dynamically from localStorage ---- */
function renderActivity() {
  const el = document.getElementById("activityList");
  const rows = [];

  function readStore(key) {
    try { return JSON.parse(localStorage.getItem(key)) || []; } catch(e){ return []; }
  }
  function fmtDate(d) {
    if (!d) return "";
    const diff = Math.floor((Date.now() - new Date(d + "T00:00:00").getTime()) / 86400000);
    if (diff === 0) return "Today";
    if (diff === 1) return "Yesterday";
    return diff + " days ago";
  }

  readStore("inv_products").forEach(p => rows.push({
    icon:"📦", bg:"#dbeafe",
    text: "Product: " + p.name + " (" + p.qty + " " + p.unit + ")",
    date: ""
  }));
  readStore("inv_receipts").forEach(r => rows.push({
    icon:"📄", bg:"#d1fae5",
    text: r.doc + " – " + r.supplier + " [" + r.status + "]",
    date: r.date
  }));
  readStore("inv_deliveries").forEach(d => rows.push({
    icon:"🚚", bg:"#fde68a",
    text: d.doc + " – " + d.customer + " [" + d.status + "]",
    date: d.date
  }));
  readStore("inv_adjustments").forEach(a => rows.push({
    icon:"⚙️", bg:"#e0e7ff",
    text: a.doc + " – " + a.product + " " + a.type + " " + a.qty,
    date: a.date
  }));
  readStore("inv_warehouse").forEach(w => rows.push({
    icon:"🏭", bg:"#fecaca",
    text: "Location: " + w.name + " (" + w.zone + ")",
    date: ""
  }));
  readStore("inv_employees").forEach(e => rows.push({
    icon:"👤", bg:"#dcfce7",
    text: "Employee: " + e.name + " – " + e.role,
    date: e.joinDate || ""
  }));

  rows.sort((a,b) => (b.date || "").localeCompare(a.date || ""));
  const shown = rows.slice(0, 10);

  if (!shown.length) {
    el.innerHTML = `<p style="color:#9ca3af;font-size:14px;text-align:center;padding:16px 0;">
      No activity yet. Start by adding products, receipts or deliveries.</p>`;
    return;
  }

  el.innerHTML = shown.map(a => `
    <div class="activity-item">
      <div class="act-icon" style="background:${a.bg};">${a.icon}</div>
      <div>
        <div class="act-text">${a.text}</div>
        <div class="act-time">${fmtDate(a.date)}</div>
      </div>
    </div>`).join("");
}

/* ---- Account stats from localStorage ---- */
function loadStats() {
  const count = key => {
    const r = localStorage.getItem(key);
    return r ? JSON.parse(r).length : "0";
  };
  document.getElementById("sProd").textContent      = count("inv_products");
  document.getElementById("sRec").textContent       = count("inv_receipts");
  document.getElementById("sDel").textContent       = count("inv_deliveries");
  document.getElementById("sAdj").textContent       = count("inv_adjustments");
  document.getElementById("sWh").textContent        = count("inv_warehouse");

  const last = localStorage.getItem("inv_last_login");
  document.getElementById("sLastLogin").textContent = last || "Just now";
}

function recordLogin() {
  const now = new Date().toLocaleString("en-IN", {
    day:"2-digit", month:"short", year:"numeric",
    hour:"2-digit", minute:"2-digit"
  });
  localStorage.setItem("inv_last_login", now);
}

/* ---- Toast ---- */
function toast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className   = "toast show" + (type ? " " + type : "");
  setTimeout(() => el.classList.remove("show"), 3000);
}
