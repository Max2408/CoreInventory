/* ============================================================
   warehouse.js – Full CRUD + search / filter / paging
   ============================================================ */

/* DEFAULT_WAREHOUSE removed – start empty */

let records     = [];
let filtered    = [];
let editingId   = null;
let deleteTarget = null;
let currentPage  = 1;
const PAGE_SIZE  = 10;

window.addEventListener("DOMContentLoaded", () => {
  load();
  buildZoneFilter();
  applyFilters();
  bindEvents();
});

function load() {
  const raw = localStorage.getItem("inv_warehouse");
  records = raw ? JSON.parse(raw) : [];
}
function save() { localStorage.setItem("inv_warehouse", JSON.stringify(records)); }
function nextId() { return records.length ? Math.max(...records.map(r => r.id)) + 1 : 1; }

function buildZoneFilter() {
  const sel = document.getElementById("filterZone");
  [...new Set(records.map(r => r.zone))].sort().forEach(z => {
    const o = document.createElement("option"); o.value = z; o.textContent = z;
    sel.appendChild(o);
  });
}
function refreshZoneFilter() {
  const sel = document.getElementById("filterZone");
  const cur = sel.value;
  while (sel.options.length > 1) sel.remove(1);
  [...new Set(records.map(r => r.zone))].sort().forEach(z => {
    const o = document.createElement("option"); o.value = z; o.textContent = z;
    sel.appendChild(o);
  });
  sel.value = cur;
}

function bindEvents() {
  document.getElementById("searchInput").addEventListener("input", applyFilters);
  document.getElementById("filterZone").addEventListener("change", applyFilters);
  document.getElementById("filterStatus").addEventListener("change", applyFilters);

  document.getElementById("logoutBtn").onclick = function () {
    alert("Logging out..."); window.location.href = "login.html";
  };

  ["whModal","viewModal","deleteModal"].forEach(id => {
    document.getElementById(id).addEventListener("click", function (e) {
      if (e.target === this) this.style.display = "none";
    });
  });

  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      ["whModal","viewModal","deleteModal"].forEach(id => {
        document.getElementById(id).style.display = "none";
      });
    }
  });
}

function applyFilters() {
  const q  = document.getElementById("searchInput").value.toLowerCase();
  const zn = document.getElementById("filterZone").value;
  const st = document.getElementById("filterStatus").value;

  filtered = records.filter(r => {
    const mq = !q  || [r.code, r.name, r.zone, r.status, r.notes].join(" ").toLowerCase().includes(q);
    const mz = !zn || r.zone === zn;
    const ms = !st || r.status === st;
    return mq && mz && ms;
  });

  currentPage = 1;
  updateStats();
  renderTable();
}

function updateStats() {
  document.getElementById("statTotal").textContent  = records.length;
  document.getElementById("statActive").textContent = records.filter(r => r.status === "Active").length;
  document.getElementById("statFull").textContent   = records.filter(r => r.status === "Full").length;
  document.getElementById("statZones").textContent  = [...new Set(records.map(r => r.zone))].length;
  document.getElementById("resultCount").textContent = `Showing ${filtered.length} of ${records.length} locations`;
}

function statusTagClass(status) {
  if (status === "Active")   return "active";
  if (status === "Full")     return "full";
  return "inactive";
}

function usagePct(r) {
  return r.capacity > 0 ? Math.min(Math.round((r.used / r.capacity) * 100), 100) : 0;
}

function usageBarHTML(r) {
  const pct   = usagePct(r);
  const color = pct >= 100 ? "#e5533d" : pct >= 75 ? "#f59e0b" : "#22c55e";
  return `<div class="usage-bar-wrap">
    <div class="usage-bar-bg"><div class="usage-bar-fill" style="width:${pct}%;background:${color};"></div></div>
    <span class="usage-pct">${pct}%</span>
  </div>`;
}

function renderTable() {
  const tbody = document.getElementById("whTbody");
  tbody.innerHTML = "";

  const page = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  renderPagination(filtered.length);

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:30px;color:#9ca3af;">No locations found.</td></tr>`;
    return;
  }

  page.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="doc">${esc(r.code)}</td>
      <td>${esc(r.name)}</td>
      <td>${esc(r.zone)}</td>
      <td>${r.capacity}</td>
      <td>${r.used}</td>
      <td>${usageBarHTML(r)}</td>
      <td><span class="tag ${statusTagClass(r.status)}">${r.status}</span></td>
      <td>
        <button class="act-btn btn-view"   onclick="viewRecord(${r.id})">👁 View</button>
        <button class="act-btn btn-edit"   onclick="openEditModal(${r.id})">✏️ Edit</button>
        <button class="act-btn btn-delete" onclick="confirmDelete(${r.id})">🗑</button>
      </td>`;
    tbody.appendChild(tr);
  });
}

function renderPagination(total) {
  const pages = Math.ceil(total / PAGE_SIZE);
  const el    = document.getElementById("pagination");
  el.innerHTML = "";
  if (pages <= 1) return;

  const prev = document.createElement("button");
  prev.className = "pg-btn"; prev.textContent = "‹ Prev";
  prev.disabled  = currentPage === 1;
  prev.onclick   = () => { currentPage--; renderTable(); };
  el.appendChild(prev);

  for (let i = 1; i <= pages; i++) {
    const btn = document.createElement("button");
    btn.className = "pg-btn" + (i === currentPage ? " active" : "");
    btn.textContent = i;
    btn.onclick = () => { currentPage = i; renderTable(); };
    el.appendChild(btn);
  }

  const next = document.createElement("button");
  next.className = "pg-btn"; next.textContent = "Next ›";
  next.disabled  = currentPage === pages;
  next.onclick   = () => { currentPage++; renderTable(); };
  el.appendChild(next);
}

function filterByAll() {
  document.getElementById("filterZone").value   = "";
  document.getElementById("filterStatus").value = "";
  document.getElementById("searchInput").value  = "";
  applyFilters();
}
function filterByStatus(status) {
  document.getElementById("filterStatus").value = status;
  document.getElementById("filterZone").value   = "";
  document.getElementById("searchInput").value  = "";
  applyFilters();
}

/* ---- Add / Edit Modal ---- */
function openAddModal() {
  editingId = null;
  document.getElementById("modalTitle").textContent = "Add Location";
  ["fCode","fName","fZone","fNotes"].forEach(id => document.getElementById(id).value = "");
  ["fCapacity","fUsed"].forEach(id => document.getElementById(id).value = "");
  document.getElementById("fStatus").value = "Active";
  document.getElementById("formError").textContent = "";
  document.getElementById("whModal").style.display = "flex";
}

function openEditModal(id) {
  editingId = id;
  const r = records.find(x => x.id === id);
  if (!r) return;
  document.getElementById("modalTitle").textContent = "Edit Location";
  document.getElementById("fCode").value     = r.code;
  document.getElementById("fName").value     = r.name;
  document.getElementById("fZone").value     = r.zone;
  document.getElementById("fStatus").value   = r.status;
  document.getElementById("fCapacity").value = r.capacity;
  document.getElementById("fUsed").value     = r.used;
  document.getElementById("fNotes").value    = r.notes || "";
  document.getElementById("formError").textContent = "";
  document.getElementById("whModal").style.display = "flex";
}

function closeModal() { document.getElementById("whModal").style.display = "none"; }

function saveRecord() {
  const code     = document.getElementById("fCode").value.trim();
  const name     = document.getElementById("fName").value.trim();
  const zone     = document.getElementById("fZone").value.trim();
  const status   = document.getElementById("fStatus").value;
  const capacity = parseInt(document.getElementById("fCapacity").value) || 0;
  const used     = parseInt(document.getElementById("fUsed").value) || 0;
  const notes    = document.getElementById("fNotes").value.trim();
  const errEl    = document.getElementById("formError");

  if (!code) { errEl.textContent = "Location code is required."; return; }
  if (!name) { errEl.textContent = "Name is required."; return; }
  if (!zone) { errEl.textContent = "Zone is required."; return; }

  const dup = records.find(r => r.code === code && r.id !== editingId);
  if (dup) { errEl.textContent = `Code "${code}" already exists.`; return; }

  if (editingId) {
    const idx = records.findIndex(r => r.id === editingId);
    records[idx] = { ...records[idx], code, name, zone, status, capacity, used, notes };
    toast("Location updated successfully!", "success");
  } else {
    records.push({ id: nextId(), code, name, zone, status, capacity, used, notes });
    toast("Location added successfully!", "success");
  }

  save(); closeModal(); refreshZoneFilter(); applyFilters();
}

/* ---- View Modal ---- */
function viewRecord(id) {
  const r = records.find(x => x.id === id);
  if (!r) return;
  const pct = usagePct(r);
  document.getElementById("viewModalBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><label>Location Code</label><span class="doc">${esc(r.code)}</span></div>
      <div class="detail-item"><label>Name</label><span>${esc(r.name)}</span></div>
      <div class="detail-item"><label>Zone</label><span>${esc(r.zone)}</span></div>
      <div class="detail-item"><label>Status</label><span class="tag ${statusTagClass(r.status)}">${r.status}</span></div>
      <div class="detail-item"><label>Capacity</label><span>${r.capacity} units</span></div>
      <div class="detail-item"><label>Used</label><span>${r.used} units</span></div>
      <div class="detail-item full-width"><label>Usage</label>${usageBarHTML(r)}<span style="font-size:13px;color:#6b7280;margin-top:4px;display:block;">${pct}% used</span></div>
      <div class="detail-item full-width"><label>Notes</label><span>${esc(r.notes) || "—"}</span></div>
    </div>`;
  document.getElementById("viewEditBtn").onclick = () => { closeViewModal(); openEditModal(id); };
  document.getElementById("viewModal").style.display = "flex";
}

function closeViewModal() { document.getElementById("viewModal").style.display = "none"; }

/* ---- Delete ---- */
function confirmDelete(id) {
  deleteTarget = id;
  const r = records.find(x => x.id === id);
  document.getElementById("deleteMsg").textContent =
    `Are you sure you want to delete location "${r ? r.code : ""}"? This cannot be undone.`;
  document.getElementById("confirmDeleteBtn").onclick = doDelete;
  document.getElementById("deleteModal").style.display = "flex";
}
function closeDeleteModal() { document.getElementById("deleteModal").style.display = "none"; }
function doDelete() {
  records = records.filter(r => r.id !== deleteTarget);
  save(); refreshZoneFilter(); applyFilters(); closeDeleteModal();
  toast("Location deleted.", "success");
}

/* ---- Utilities ---- */
function esc(str) {
  return String(str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function toast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className   = "toast show" + (type ? " " + type : "");
  setTimeout(() => el.classList.remove("show"), 3000);
}
