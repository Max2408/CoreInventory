/* ============================================================
   inventory-adjust.js – Full CRUD + search / filter / paging
   ============================================================ */

/* DEFAULT_ADJUSTMENTS removed – start empty */

let records     = [];
let filtered    = [];
let editingId   = null;
let deleteTarget = null;
let currentPage  = 1;
const PAGE_SIZE  = 10;

window.addEventListener("DOMContentLoaded", () => {
  load();
  applyFilters();
  bindEvents();
});

function load() {
  const raw = localStorage.getItem("inv_adjustments");
  records = raw ? JSON.parse(raw) : [];
}
function save() { localStorage.setItem("inv_adjustments", JSON.stringify(records)); }
function nextId()  { return records.length ? Math.max(...records.map(r => r.id)) + 1 : 1; }
function nextDoc() { return "ADJ-" + String(records.length + 1).padStart(3, "0"); }

function bindEvents() {
  document.getElementById("searchInput").addEventListener("input", applyFilters);
  document.getElementById("filterType").addEventListener("change", applyFilters);
  document.getElementById("filterStatus").addEventListener("change", applyFilters);

  document.getElementById("logoutBtn").onclick = function () {
    alert("Logging out...");
    window.location.href = "login.html";
  };

  ["adjModal","viewModal","deleteModal"].forEach(id => {
    document.getElementById(id).addEventListener("click", function (e) {
      if (e.target === this) this.style.display = "none";
    });
  });

  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      ["adjModal","viewModal","deleteModal"].forEach(id => {
        document.getElementById(id).style.display = "none";
      });
    }
  });
}

function applyFilters() {
  const q  = document.getElementById("searchInput").value.toLowerCase();
  const tp = document.getElementById("filterType").value;
  const st = document.getElementById("filterStatus").value;

  filtered = records.filter(r => {
    const mq = !q  || [r.doc, r.product, r.type, r.location, r.reason, r.notes].join(" ").toLowerCase().includes(q);
    const mt = !tp || r.type === tp;
    const ms = !st || r.status === st;
    return mq && mt && ms;
  });

  currentPage = 1;
  updateStats();
  renderTable();
}

function updateStats() {
  document.getElementById("statTotal").textContent  = records.length;
  document.getElementById("statAdd").textContent    = records.filter(r => r.type === "Add").length;
  document.getElementById("statRemove").textContent = records.filter(r => r.type === "Remove").length;
  document.getElementById("statDone").textContent   = records.filter(r => r.status === "Done").length;
  document.getElementById("resultCount").textContent = `Showing ${filtered.length} of ${records.length} adjustments`;
}

function typeTagClass(type) {
  if (type === "Add")    return "type-add";
  if (type === "Remove") return "type-remove";
  return "type-set";
}
function statusTagClass(status) {
  return status === "Done" ? "done" : "draft";
}
function qtyDisplay(r) {
  if (r.type === "Add")    return `<span class="qty-add">+${r.qty}</span>`;
  if (r.type === "Remove") return `<span class="qty-remove">−${r.qty}</span>`;
  return `<span class="qty-set">=${r.qty}</span>`;
}

function formatDate(d) {
  if (!d) return "—";
  return new Date(d + "T00:00:00").toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"numeric" });
}

function renderTable() {
  const tbody = document.getElementById("adjTbody");
  tbody.innerHTML = "";

  const page = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  renderPagination(filtered.length);

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:30px;color:#9ca3af;">No adjustments found.</td></tr>`;
    return;
  }

  page.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="doc">${esc(r.doc)}</td>
      <td>${esc(r.product)}</td>
      <td><span class="tag ${typeTagClass(r.type)}">${r.type}</span></td>
      <td>${qtyDisplay(r)}</td>
      <td style="color:#6b7280;font-size:13px;">${esc(r.location) || "—"}</td>
      <td>${formatDate(r.date)}</td>
      <td><span class="tag ${statusTagClass(r.status)}">${r.status}</span></td>
      <td>
        <button class="act-btn btn-view"   onclick="viewRecord(${r.id})">👁 View</button>
        <button class="act-btn btn-edit"   onclick="openEditModal(${r.id})">✏️ Edit</button>
        <button class="act-btn btn-delete" onclick="confirmDelete(${r.id})">🗑</button>
      </td>`;
    tbody.appendChild(tr);
  });
}

function renderPagination(total) {
  const pages = Math.ceil(total / PAGE_SIZE);
  const el    = document.getElementById("pagination");
  el.innerHTML = "";
  if (pages <= 1) return;

  const prev = document.createElement("button");
  prev.className = "pg-btn"; prev.textContent = "‹ Prev";
  prev.disabled  = currentPage === 1;
  prev.onclick   = () => { currentPage--; renderTable(); };
  el.appendChild(prev);

  for (let i = 1; i <= pages; i++) {
    const btn = document.createElement("button");
    btn.className = "pg-btn" + (i === currentPage ? " active" : "");
    btn.textContent = i;
    btn.onclick = () => { currentPage = i; renderTable(); };
    el.appendChild(btn);
  }

  const next = document.createElement("button");
  next.className = "pg-btn"; next.textContent = "Next ›";
  next.disabled  = currentPage === pages;
  next.onclick   = () => { currentPage++; renderTable(); };
  el.appendChild(next);
}

function filterByAll() {
  document.getElementById("filterType").value   = "";
  document.getElementById("filterStatus").value = "";
  document.getElementById("searchInput").value  = "";
  applyFilters();
}
function filterByType(type) {
  document.getElementById("filterType").value   = type;
  document.getElementById("filterStatus").value = "";
  document.getElementById("searchInput").value  = "";
  applyFilters();
}
function filterByStatus(status) {
  document.getElementById("filterStatus").value = status;
  document.getElementById("filterType").value   = "";
  document.getElementById("searchInput").value  = "";
  applyFilters();
}

/* ---- Add / Edit Modal ---- */
function openAddModal() {
  editingId = null;
  document.getElementById("modalTitle").textContent = "New Adjustment";
  document.getElementById("fDoc").value      = nextDoc();
  document.getElementById("fDate").value     = new Date().toISOString().split("T")[0];
  document.getElementById("fProduct").value  = "";
  document.getElementById("fType").value     = "Add";
  document.getElementById("fQty").value      = "";
  document.getElementById("fLocation").value = "";
  document.getElementById("fStatus").value   = "Draft";
  document.getElementById("fReason").value   = "";
  document.getElementById("fNotes").value    = "";
  document.getElementById("formError").textContent = "";
  document.getElementById("adjModal").style.display = "flex";
}

function openEditModal(id) {
  editingId = id;
  const r = records.find(x => x.id === id);
  if (!r) return;
  document.getElementById("modalTitle").textContent = "Edit Adjustment";
  document.getElementById("fDoc").value      = r.doc;
  document.getElementById("fDate").value     = r.date;
  document.getElementById("fProduct").value  = r.product;
  document.getElementById("fType").value     = r.type;
  document.getElementById("fQty").value      = r.qty;
  document.getElementById("fLocation").value = r.location || "";
  document.getElementById("fStatus").value   = r.status;
  document.getElementById("fReason").value   = r.reason  || "";
  document.getElementById("fNotes").value    = r.notes   || "";
  document.getElementById("formError").textContent = "";
  document.getElementById("adjModal").style.display = "flex";
}

function closeModal() {
  document.getElementById("adjModal").style.display = "none";
}

function saveRecord() {
  const product  = document.getElementById("fProduct").value.trim();
  const date     = document.getElementById("fDate").value;
  const type     = document.getElementById("fType").value;
  const qty      = parseInt(document.getElementById("fQty").value);
  const location = document.getElementById("fLocation").value.trim();
  const status   = document.getElementById("fStatus").value;
  const reason   = document.getElementById("fReason").value.trim();
  const notes    = document.getElementById("fNotes").value.trim();
  const errEl    = document.getElementById("formError");

  if (!product)        { errEl.textContent = "Product name is required."; return; }
  if (!date)           { errEl.textContent = "Date is required."; return; }
  if (isNaN(qty) || qty < 0) { errEl.textContent = "Enter a valid quantity."; return; }

  if (editingId) {
    const idx = records.findIndex(r => r.id === editingId);
    records[idx] = { ...records[idx], product, date, type, qty, location, status, reason, notes };
    toast("Adjustment updated successfully!", "success");
  } else {
    records.push({ id: nextId(), doc: nextDoc(), product, date, type, qty, location, status, reason, notes });
    toast("Adjustment created successfully!", "success");
  }

  save();
  closeModal();
  applyFilters();
}

/* ---- View Modal ---- */
function viewRecord(id) {
  const r = records.find(x => x.id === id);
  if (!r) return;
  document.getElementById("viewModalBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><label>Document No.</label><span class="doc">${esc(r.doc)}</span></div>
      <div class="detail-item"><label>Date</label><span>${formatDate(r.date)}</span></div>
      <div class="detail-item"><label>Product</label><span>${esc(r.product)}</span></div>
      <div class="detail-item"><label>Type</label><span class="tag ${typeTagClass(r.type)}">${r.type}</span></div>
      <div class="detail-item"><label>Qty Change</label><span style="font-size:20px;">${qtyDisplay(r)}</span></div>
      <div class="detail-item"><label>Status</label><span class="tag ${statusTagClass(r.status)}">${r.status}</span></div>
      <div class="detail-item"><label>Location</label><span>${esc(r.location) || "—"}</span></div>
      <div class="detail-item"><label>Reason</label><span>${esc(r.reason) || "—"}</span></div>
      <div class="detail-item full-width"><label>Notes</label><span>${esc(r.notes) || "—"}</span></div>
    </div>`;
  document.getElementById("viewEditBtn").onclick = () => { closeViewModal(); openEditModal(id); };
  document.getElementById("viewModal").style.display = "flex";
}

function closeViewModal() {
  document.getElementById("viewModal").style.display = "none";
}

/* ---- Delete ---- */
function confirmDelete(id) {
  deleteTarget = id;
  const r = records.find(x => x.id === id);
  document.getElementById("deleteMsg").textContent =
    `Are you sure you want to delete adjustment "${r ? r.doc : ""}"? This cannot be undone.`;
  document.getElementById("confirmDeleteBtn").onclick = doDelete;
  document.getElementById("deleteModal").style.display = "flex";
}
function closeDeleteModal() {
  document.getElementById("deleteModal").style.display = "none";
}
function doDelete() {
  records = records.filter(r => r.id !== deleteTarget);
  save();
  applyFilters();
  closeDeleteModal();
  toast("Adjustment deleted.", "success");
}

/* ---- Utilities ---- */
function esc(str) {
  return String(str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function toast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className   = "toast show" + (type ? " " + type : "");
  setTimeout(() => el.classList.remove("show"), 3000);
}
