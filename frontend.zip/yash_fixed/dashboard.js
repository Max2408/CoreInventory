/* ============================================================
   dashboard.js  –  Fully dynamic, reads from localStorage
   ============================================================ */

/* ── Navigation ── */
function viewProducts()  { window.location.href = "products.html"; }
function viewLowStock()  { window.location.href = "products.html?filter=low"; }
function viewReceipts()  { window.location.href = "receipts.html"; }
function viewDeliveries(){ window.location.href = "delivery.html"; }
function viewTransfers() { window.location.href = "move-history.html"; }
function viewEmployees() { window.location.href = "employees.html"; }
function viewAllActivity(){ window.location.href = "move-history.html"; }
function newOperation()  { alert("Create New Inventory Operation"); }

/* ── Helpers ── */
function readStore(key) {
  try { return JSON.parse(localStorage.getItem(key)) || []; }
  catch(e) { return []; }
}

function getProductStatus(p) {
  if (p.qty === 0) return "Out of Stock";
  if (p.reorder > 0 && p.qty <= p.reorder) return "Low Stock";
  return "In Stock";
}

function formatDate(d) {
  if (!d) return "—";
  return new Date(d + "T00:00:00").toLocaleDateString("en-IN",
    { day:"2-digit", month:"short", year:"numeric" });
}

function tagClass(status) {
  const map = {
    Waiting:"waiting", Ready:"ready", Done:"done",
    Draft:"draft", Cancelled:"cancelled"
  };
  return map[status] || "waiting";
}

function esc(str) {
  return String(str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;")
    .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

/* ── Load & render stats ── */
function loadStats() {
  const products   = readStore("inv_products");
  const receipts   = readStore("inv_receipts");
  const deliveries = readStore("inv_deliveries");
  const employees  = readStore("inv_employees");

  const totalQty   = products.reduce((s, p) => s + (parseInt(p.qty) || 0), 0);
  const lowStock   = products.filter(p => getProductStatus(p) !== "In Stock").length;
  const pendingRec = receipts.filter(r => r.status === "Waiting" || r.status === "Ready").length;
  const pendingDel = deliveries.filter(d => d.status === "Waiting" || d.status === "Ready").length;

  document.getElementById("statProducts").textContent   = totalQty.toLocaleString("en-IN");
  document.getElementById("statLowStock").textContent   = lowStock;
  document.getElementById("statReceipts").textContent   = pendingRec;
  document.getElementById("statDeliveries").textContent = pendingDel;
  document.getElementById("statEmployees").textContent  = employees.length;
}

/* ── Build recent activity from all modules ── */
function loadActivity() {
  const allRows = [];

  readStore("inv_receipts").forEach(r => {
    allRows.push({
      doc:    r.doc,
      type:   "Receipt",
      status: r.status,
      detail: "Supplier: <b>" + esc(r.supplier) + "</b>",
      date:   r.date || ""
    });
  });

  readStore("inv_deliveries").forEach(d => {
    allRows.push({
      doc:    d.doc,
      type:   "Delivery",
      status: d.status,
      detail: "Customer: <b>" + esc(d.customer) + "</b>",
      date:   d.date || ""
    });
  });

  readStore("inv_adjustments").forEach(a => {
    allRows.push({
      doc:    a.doc,
      type:   "Adjustment",
      status: a.status,
      detail: esc(a.product) + " — " + esc(a.type) + " " + a.qty,
      date:   a.date || ""
    });
  });

  allRows.sort((a, b) => b.date.localeCompare(a.date));

  const tbody   = document.getElementById("dashTbody");
  const countEl = document.getElementById("dashResultCount");

  const docType = document.getElementById("docType").value;
  const status  = document.getElementById("status").value;
  const search  = document.getElementById("search").value.toLowerCase();

  const filtered = allRows.filter(r => {
    const matchType   = !docType || docType === "All" || r.type === docType;
    const matchStatus = !status  || status  === "All" || r.status === status;
    const matchSearch = !search  || [r.doc, r.type, r.status, r.detail]
                          .join(" ").toLowerCase().includes(search);
    return matchType && matchStatus && matchSearch;
  });

  const shown = filtered.slice(0, 20);
  countEl.textContent = shown.length + " of " + allRows.length + " records";

  if (!shown.length) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:30px;color:#9ca3af;">
      No activity yet. Start by adding products, receipts or deliveries.</td></tr>`;
    return;
  }

  tbody.innerHTML = shown.map(r => `
    <tr>
      <td class="doc">${esc(r.doc)}</td>
      <td>${esc(r.type)}</td>
      <td><span class="tag ${tagClass(r.status)}">${esc(r.status)}</span></td>
      <td>${r.detail}</td>
      <td>${formatDate(r.date)}</td>
    </tr>`).join("");
}

/* ── Populate status filter dynamically ── */
function buildFilterOptions() {
  const allStatuses = new Set();
  ["inv_receipts","inv_deliveries","inv_adjustments"].forEach(key => {
    readStore(key).forEach(r => allStatuses.add(r.status));
  });

  const statusSel = document.getElementById("status");
  statusSel.innerHTML = '<option value="">All Statuses</option>';
  [...allStatuses].sort().forEach(s => {
    const o = document.createElement("option");
    o.value = s; o.textContent = s;
    statusSel.appendChild(o);
  });
}

/* ── Init ── */
window.addEventListener("DOMContentLoaded", () => {
  loadStats();
  buildFilterOptions();
  loadActivity();

  document.getElementById("docType").addEventListener("change", loadActivity);
  document.getElementById("status").addEventListener("change", loadActivity);
  document.getElementById("search").addEventListener("input", loadActivity);

  document.getElementById("logoutBtn").onclick = function() {
    alert("Logging out...");
    window.location.href = "login.html";
  };
});
