/* ============================================================
   profile.js – Personal profile, password change, stats
   ============================================================ */

const PROFILE_KEY = "inv_profile";

const RECENT_ACTIVITY = [
  { icon:"📦", bg:"#dbeafe", text:"Added product Steel Bolt M8",        time:"2 hours ago" },
  { icon:"📄", bg:"#d1fae5", text:"Created receipt REC-007",             time:"Yesterday" },
  { icon:"🚚", bg:"#fde68a", text:"Updated delivery DEL-003 to Done",    time:"2 days ago" },
  { icon:"⚙️", bg:"#e0e7ff", text:"Adjusted inventory ADJ-006",          time:"3 days ago" },
  { icon:"🏭", bg:"#fecaca", text:"Added warehouse location C-02-01",    time:"4 days ago" },
];

window.addEventListener("DOMContentLoaded", () => {
  loadProfile();
  renderActivity();
  loadStats();
  recordLogin();

  document.getElementById("logoutBtn").onclick = function () {
    alert("Logging out..."); window.location.href = "login.html";
  };
});

/* ---- Load saved profile ---- */
function loadProfile() {
  const raw = localStorage.getItem(PROFILE_KEY);
  if (!raw) return;
  const p = JSON.parse(raw);

  if (p.name)   { document.getElementById("pName").value = p.name;   updateBanner("bannerName", p.name); }
  if (p.email)  { document.getElementById("pEmail").value = p.email; updateBanner("bannerEmail", p.email); }
  if (p.phone)  document.getElementById("pPhone").value  = p.phone;
  if (p.dept)   document.getElementById("pDept").value   = p.dept;
  if (p.role)   { document.getElementById("pRole").value = p.role;   updateBanner("bannerRole", p.role); }
  if (p.avatar) document.getElementById("profileAvatar").src = p.avatar;
}

/* ---- Save profile ---- */
function saveProfile() {
  const name  = document.getElementById("pName").value.trim();
  const email = document.getElementById("pEmail").value.trim();
  const errEl = document.getElementById("profileError");

  if (!name)  { errEl.textContent = "Full name is required.";     return; }
  if (!email) { errEl.textContent = "Email address is required."; return; }
  errEl.textContent = "";

  const profile = {
    name,
    email,
    phone:  document.getElementById("pPhone").value.trim(),
    dept:   document.getElementById("pDept").value.trim(),
    role:   document.getElementById("pRole").value.trim(),
    avatar: document.getElementById("profileAvatar").src,
  };

  localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));

  updateBanner("bannerName",  name);
  updateBanner("bannerEmail", email);

  toast("Profile saved successfully!", "success");
}

function updateBanner(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

/* ---- Change password ---- */
function changePassword() {
  const curr  = document.getElementById("pCurrPwd").value;
  const nw    = document.getElementById("pNewPwd").value;
  const conf  = document.getElementById("pConfPwd").value;
  const errEl = document.getElementById("pwdError");

  if (!curr)       { errEl.textContent = "Current password is required.";          return; }
  if (nw.length < 6) { errEl.textContent = "New password must be at least 6 characters."; return; }
  if (nw !== conf) { errEl.textContent = "Passwords do not match.";                return; }

  errEl.textContent = "";
  document.getElementById("pCurrPwd").value = "";
  document.getElementById("pNewPwd").value  = "";
  document.getElementById("pConfPwd").value = "";

  toast("Password updated successfully!", "success");
}

/* ---- Change avatar ---- */
function changeAvatar(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById("profileAvatar").src = e.target.result;

    const raw = localStorage.getItem(PROFILE_KEY);
    const p   = raw ? JSON.parse(raw) : {};
    p.avatar  = e.target.result;
    localStorage.setItem(PROFILE_KEY, JSON.stringify(p));

    toast("Profile photo updated!", "success");
  };
  reader.readAsDataURL(file);
}

/* ---- Recent activity ---- */
function renderActivity() {
  const el = document.getElementById("activityList");
  el.innerHTML = RECENT_ACTIVITY.map(a => `
    <div class="activity-item">
      <div class="act-icon" style="background:${a.bg};">${a.icon}</div>
      <div>
        <div class="act-text">${a.text}</div>
        <div class="act-time">${a.time}</div>
      </div>
    </div>`).join("");
}

/* ---- Account stats from localStorage ---- */
function loadStats() {
  const count = key => {
    const r = localStorage.getItem(key);
    return r ? JSON.parse(r).length : "0";
  };
  document.getElementById("sProd").textContent      = count("inv_products");
  document.getElementById("sRec").textContent       = count("inv_receipts");
  document.getElementById("sDel").textContent       = count("inv_deliveries");
  document.getElementById("sAdj").textContent       = count("inv_adjustments");
  document.getElementById("sWh").textContent        = count("inv_warehouse");

  const last = localStorage.getItem("inv_last_login");
  document.getElementById("sLastLogin").textContent = last || "Just now";
}

function recordLogin() {
  const now = new Date().toLocaleString("en-IN", {
    day:"2-digit", month:"short", year:"numeric",
    hour:"2-digit", minute:"2-digit"
  });
  localStorage.setItem("inv_last_login", now);
}

/* ---- Toast ---- */
function toast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className   = "toast show" + (type ? " " + type : "");
  setTimeout(() => el.classList.remove("show"), 3000);
}
