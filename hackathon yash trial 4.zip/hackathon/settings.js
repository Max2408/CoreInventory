/* ============================================================
   settings.js – Save / load all app settings
   ============================================================ */

const SETTINGS_KEY = "inv_settings";

window.addEventListener("DOMContentLoaded", () => {
  loadSettings();

  document.getElementById("logoutBtn").onclick = function () {
    alert("Logging out..."); window.location.href = "login.html";
  };
});

function loadSettings() {
  const raw = localStorage.getItem(SETTINGS_KEY);
  if (!raw) return;
  const s = JSON.parse(raw);

  if (s.company)     document.getElementById("sCompany").value     = s.company;
  if (s.currency)    document.getElementById("sCurrency").value    = s.currency;
  if (s.dateFormat)  document.getElementById("sDateFormat").value  = s.dateFormat;
  if (s.pageSize)    document.getElementById("sPageSize").value    = s.pageSize;
  if (s.defaultUnit) document.getElementById("sDefaultUnit").value = s.defaultUnit;
  if (s.email)       document.getElementById("sEmail").value       = s.email;

  document.getElementById("sLowAlert").checked     = s.lowAlert     !== false;
  document.getElementById("sOutAlert").checked     = s.outAlert     !== false;
  document.getElementById("sAutoDoc").checked      = s.autoDoc      !== false;
  document.getElementById("sEmailNotif").checked   = !!s.emailNotif;
  document.getElementById("sNotifReceipt").checked  = s.notifReceipt  !== false;
  document.getElementById("sNotifDelivery").checked = s.notifDelivery !== false;
}

function saveSettings() {
  const s = {
    company:        document.getElementById("sCompany").value.trim(),
    currency:       document.getElementById("sCurrency").value.trim(),
    dateFormat:     document.getElementById("sDateFormat").value,
    pageSize:       parseInt(document.getElementById("sPageSize").value) || 10,
    defaultUnit:    document.getElementById("sDefaultUnit").value,
    email:          document.getElementById("sEmail").value.trim(),
    lowAlert:       document.getElementById("sLowAlert").checked,
    outAlert:       document.getElementById("sOutAlert").checked,
    autoDoc:        document.getElementById("sAutoDoc").checked,
    emailNotif:     document.getElementById("sEmailNotif").checked,
    notifReceipt:   document.getElementById("sNotifReceipt").checked,
    notifDelivery:  document.getElementById("sNotifDelivery").checked,
  };
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  toast("Settings saved successfully!", "success");
}

function exportAll() {
  const keys = [
    "inv_products","inv_receipts","inv_deliveries",
    "inv_adjustments","inv_warehouse","inv_history","inv_settings"
  ];
  const data = {};
  keys.forEach(k => {
    const v = localStorage.getItem(k);
    if (v) data[k] = JSON.parse(v);
  });
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "inventory_backup.json";
  a.click();
  toast("Data exported successfully!", "success");
}

function clearData(key, name) {
  if (!confirm(`Clear all ${name} data? This cannot be undone.`)) return;
  localStorage.removeItem(key);
  toast(`${name} data cleared.`, "success");
}

function resetAll() {
  if (!confirm("Reset ALL inventory data? Everything will be wiped and restored to defaults on next visit.")) return;
  [
    "inv_products","inv_receipts","inv_deliveries",
    "inv_adjustments","inv_warehouse","inv_history","inv_settings"
  ].forEach(k => localStorage.removeItem(k));
  toast("All data reset. Redirecting to dashboard…", "success");
  setTimeout(() => window.location.href = "dashboard.html", 1800);
}

function toast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className   = "toast show" + (type ? " " + type : "");
  setTimeout(() => el.classList.remove("show"), 3000);
}
