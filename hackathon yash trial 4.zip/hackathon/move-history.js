/* ============================================================
   move-history.js – Read-only movement log with filters
   ============================================================ */

const DEFAULT_HISTORY = [
  { id:1,  ref:"TRF-001", type:"Transfer",   product:"Steel Bolt M8",       qty:50,  from:"Main Warehouse",        to:"Production Rack",         date:"2024-04-08", by:"Admin", notes:"Moved for assembly line" },
  { id:2,  ref:"REC-002", type:"Receipt",    product:"Copper Wire 2.5mm",   qty:100, from:"Supplier: WireWorld",   to:"Aisle C – Rack 2",        date:"2024-04-08", by:"Admin", notes:"Received in full" },
  { id:3,  ref:"DEL-001", type:"Delivery",   product:"Finished Gear A",     qty:10,  from:"Aisle E – Rack 1",     to:"Customer: Home Goods",    date:"2024-04-09", by:"Admin", notes:"" },
  { id:4,  ref:"ADJ-001", type:"Adjustment", product:"Steel Bolt M8",       qty:100, from:"—",                    to:"Aisle A – Rack 1",        date:"2024-04-07", by:"Admin", notes:"Purchase restock" },
  { id:5,  ref:"TRF-002", type:"Transfer",   product:"Bearing 6205 ZZ",     qty:5,   from:"Main Warehouse",        to:"Repair Station",          date:"2024-04-10", by:"Admin", notes:"" },
  { id:6,  ref:"DEL-002", type:"Delivery",   product:"Steel Bolt M8",       qty:500, from:"Aisle A – Rack 1",     to:"Customer: BuildMart",     date:"2024-04-11", by:"Admin", notes:"Fragile" },
  { id:7,  ref:"ADJ-002", type:"Adjustment", product:"Packaging Box L",     qty:10,  from:"Aisle D – Rack 5",     to:"—",                       date:"2024-04-06", by:"Admin", notes:"Damaged – removed" },
  { id:8,  ref:"REC-003", type:"Receipt",    product:"Packaging Box L",     qty:50,  from:"Supplier: PackPro",    to:"Aisle D – Rack 5",        date:"2024-04-12", by:"Admin", notes:"Inspect on arrival" },
  { id:9,  ref:"DEL-003", type:"Delivery",   product:"LED Driver 24V",      qty:5,   from:"Aisle C – Rack 1",     to:"Customer: TechZone",      date:"2024-04-07", by:"Admin", notes:"Delivered on time" },
  { id:10, ref:"TRF-003", type:"Transfer",   product:"Hydraulic Oil 5W",    qty:20,  from:"Main Warehouse",        to:"Aisle B – Rack 3",        date:"2024-04-09", by:"Admin", notes:"" },
  { id:11, ref:"REC-004", type:"Receipt",    product:"Hydraulic Oil 5W",    qty:40,  from:"Supplier: OilTech",    to:"Aisle B – Rack 3",        date:"2024-04-15", by:"Admin", notes:"" },
  { id:12, ref:"ADJ-003", type:"Adjustment", product:"Bearing 6205 ZZ",     qty:20,  from:"—",                    to:"Aisle B – Rack 7",        date:"2024-04-08", by:"Admin", notes:"Audit recount" },
];

let records     = [];
let filtered    = [];
let currentPage  = 1;
const PAGE_SIZE  = 10;

window.addEventListener("DOMContentLoaded", () => {
  load();
  applyFilters();
  bindEvents();
});

function load() {
  /* Seed from localStorage or defaults; also pull in live records from other modules */
  const raw = localStorage.getItem("inv_history");
  records = raw ? JSON.parse(raw) : JSON.parse(JSON.stringify(DEFAULT_HISTORY));

  /* Merge any receipts saved by receipts.js */
  const rawRec = localStorage.getItem("inv_receipts");
  if (rawRec) {
    const recs = JSON.parse(rawRec);
    recs.forEach(r => {
      if (!records.find(h => h.ref === r.doc && h.type === "Receipt")) {
        records.push({ id: records.length + 1, ref: r.doc, type: "Receipt", product: r.products || "—",
          qty: "—", from: "Supplier: " + r.supplier, to: "Warehouse", date: r.date, by: "Admin", notes: r.notes || "" });
      }
    });
  }

  /* Merge deliveries */
  const rawDel = localStorage.getItem("inv_deliveries");
  if (rawDel) {
    const dels = JSON.parse(rawDel);
    dels.forEach(d => {
      if (!records.find(h => h.ref === d.doc && h.type === "Delivery")) {
        records.push({ id: records.length + 1, ref: d.doc, type: "Delivery", product: d.products || "—",
          qty: "—", from: "Warehouse", to: "Customer: " + d.customer, date: d.date, by: "Admin", notes: d.notes || "" });
      }
    });
  }

  /* Merge adjustments */
  const rawAdj = localStorage.getItem("inv_adjustments");
  if (rawAdj) {
    const adjs = JSON.parse(rawAdj);
    adjs.forEach(a => {
      if (!records.find(h => h.ref === a.doc && h.type === "Adjustment")) {
        records.push({ id: records.length + 1, ref: a.doc, type: "Adjustment", product: a.product || "—",
          qty: a.qty, from: "—", to: a.location || "Warehouse", date: a.date, by: "Admin", notes: a.reason || "" });
      }
    });
  }

  /* Sort newest first */
  records.sort((a, b) => b.date.localeCompare(a.date));
}

function bindEvents() {
  document.getElementById("searchInput").addEventListener("input", applyFilters);
  document.getElementById("filterType").addEventListener("change", applyFilters);
  document.getElementById("filterFrom").addEventListener("change", applyFilters);
  document.getElementById("filterTo").addEventListener("change", applyFilters);

  document.getElementById("logoutBtn").onclick = function () {
    alert("Logging out...");
    window.location.href = "login.html";
  };

  document.getElementById("viewModal").addEventListener("click", function (e) {
    if (e.target === this) this.style.display = "none";
  });

  document.addEventListener("keydown", e => {
    if (e.key === "Escape") document.getElementById("viewModal").style.display = "none";
  });
}

function applyFilters() {
  const q    = document.getElementById("searchInput").value.toLowerCase();
  const tp   = document.getElementById("filterType").value;
  const from = document.getElementById("filterFrom").value;
  const to   = document.getElementById("filterTo").value;

  filtered = records.filter(r => {
    const mq  = !q    || [r.ref, r.type, r.product, r.from, r.to, r.by, r.notes].join(" ").toLowerCase().includes(q);
    const mt  = !tp   || r.type === tp;
    const mf  = !from || r.date >= from;
    const mto = !to   || r.date <= to;
    return mq && mt && mf && mto;
  });

  currentPage = 1;
  updateStats();
  renderTable();
}

function updateStats() {
  document.getElementById("statTotal").textContent    = records.length;
  document.getElementById("statTransfer").textContent = records.filter(r => r.type === "Transfer").length;
  document.getElementById("statReceipt").textContent  = records.filter(r => r.type === "Receipt").length;
  document.getElementById("statDelivery").textContent = records.filter(r => r.type === "Delivery").length;
  document.getElementById("resultCount").textContent  = `Showing ${filtered.length} of ${records.length} movements`;
}

function typeTagClass(type) {
  const map = { Transfer:"transfer", Receipt:"receipt", Delivery:"delivery", Adjustment:"adjustment" };
  return map[type] || "transfer";
}

function formatDate(d) {
  if (!d) return "—";
  return new Date(d + "T00:00:00").toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"numeric" });
}

function renderTable() {
  const tbody = document.getElementById("histTbody");
  tbody.innerHTML = "";

  const page = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  renderPagination(filtered.length);

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:30px;color:#9ca3af;">No movements found.</td></tr>`;
    return;
  }

  page.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="doc">${esc(r.ref)}</td>
      <td><span class="tag ${typeTagClass(r.type)}">${r.type}</span></td>
      <td>${esc(r.product)}</td>
      <td class="qty-cell">${esc(String(r.qty))}</td>
      <td style="color:#6b7280;font-size:13px;max-width:150px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(r.from)}</td>
      <td style="color:#6b7280;font-size:13px;max-width:150px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(r.to)}</td>
      <td>${formatDate(r.date)}</td>
      <td>${esc(r.by)}</td>`;
    tr.style.cursor = "pointer";
    tr.onclick = () => viewRecord(r.id);
    tbody.appendChild(tr);
  });
}

function renderPagination(total) {
  const pages = Math.ceil(total / PAGE_SIZE);
  const el    = document.getElementById("pagination");
  el.innerHTML = "";
  if (pages <= 1) return;

  const prev = document.createElement("button");
  prev.className = "pg-btn"; prev.textContent = "‹ Prev";
  prev.disabled  = currentPage === 1;
  prev.onclick   = () => { currentPage--; renderTable(); };
  el.appendChild(prev);

  for (let i = 1; i <= pages; i++) {
    const btn = document.createElement("button");
    btn.className = "pg-btn" + (i === currentPage ? " active" : "");
    btn.textContent = i;
    btn.onclick = () => { currentPage = i; renderTable(); };
    el.appendChild(btn);
  }

  const next = document.createElement("button");
  next.className = "pg-btn"; next.textContent = "Next ›";
  next.disabled  = currentPage === pages;
  next.onclick   = () => { currentPage++; renderTable(); };
  el.appendChild(next);
}

/* ---- Quick filters from stat cards ---- */
function filterByAll() {
  document.getElementById("filterType").value = "";
  document.getElementById("filterFrom").value = "";
  document.getElementById("filterTo").value   = "";
  document.getElementById("searchInput").value = "";
  applyFilters();
}
function filterByType(type) {
  document.getElementById("filterType").value  = type;
  document.getElementById("filterFrom").value  = "";
  document.getElementById("filterTo").value    = "";
  document.getElementById("searchInput").value = "";
  applyFilters();
}
function clearFilters() {
  filterByAll();
}

/* ---- View Modal ---- */
function viewRecord(id) {
  const r = records.find(x => x.id === id);
  if (!r) return;
  document.getElementById("viewModalBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><label>Ref. No.</label><span class="doc">${esc(r.ref)}</span></div>
      <div class="detail-item"><label>Type</label><span class="tag ${typeTagClass(r.type)}">${r.type}</span></div>
      <div class="detail-item"><label>Product</label><span>${esc(r.product)}</span></div>
      <div class="detail-item"><label>Quantity</label><span class="qty-cell">${esc(String(r.qty))}</span></div>
      <div class="detail-item"><label>Date</label><span>${formatDate(r.date)}</span></div>
      <div class="detail-item"><label>Done By</label><span>${esc(r.by)}</span></div>
      <div class="detail-item full-width"><label>From</label><span>${esc(r.from)}</span></div>
      <div class="detail-item full-width"><label>To</label><span>${esc(r.to)}</span></div>
      <div class="detail-item full-width"><label>Notes</label><span>${esc(r.notes) || "—"}</span></div>
    </div>`;
  document.getElementById("viewModal").style.display = "flex";
}
function closeViewModal() {
  document.getElementById("viewModal").style.display = "none";
}

/* ---- Utilities ---- */
function esc(str) {
  return String(str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function toast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className   = "toast show" + (type ? " " + type : "");
  setTimeout(() => el.classList.remove("show"), 3000);
}
