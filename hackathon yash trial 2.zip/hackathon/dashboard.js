function viewProducts(){
window.location.href = "products.html";
}

function viewLowStock(){
window.location.href = "products.html?filter=low";
}

function viewReceipts(){
window.location.href = "receipts.html";
}

function viewDeliveries(){
window.location.href = "delivery.html";
}

function viewTransfers(){
alert("Opening Transfers");
}

function newOperation(){
alert("Create New Inventory Operation");
}

document.getElementById("logoutBtn").onclick = function(){
alert("Logging out...");
window.location.href="login.html";
};


/* Search filter */

document.getElementById("search").addEventListener("keyup",function(){

let filter=this.value.toLowerCase();
let rows=document.querySelectorAll("#table tbody tr");

rows.forEach(row=>{

let text=row.innerText.toLowerCase();

row.style.display=text.includes(filter) ? "" : "none";

});

});