/* ============================================================
   receipts.js  –  Full CRUD + search / filter / sort / paging
   ============================================================ */

/* ---- Default seed data ---- */
const DEFAULT_RECEIPTS = [
  { id:1, doc:"REC-001", supplier:"SteelMart",   products:"Steel Bolt M8 x 200, Nut M8 x 200",  date:"2024-04-10", status:"Waiting",   notes:"" },
  { id:2, doc:"REC-002", supplier:"WireWorld",    products:"Copper Wire 2.5mm x 100m",            date:"2024-04-08", status:"Done",      notes:"Received in full" },
  { id:3, doc:"REC-003", supplier:"PackPro",      products:"Packaging Box L x 50",                date:"2024-04-12", status:"Ready",     notes:"Inspect on arrival" },
  { id:4, doc:"REC-004", supplier:"OilTech",      products:"Hydraulic Oil 5W x 20ltr",            date:"2024-04-15", status:"Waiting",   notes:"" },
  { id:5, doc:"REC-005", supplier:"BearingHub",   products:"Bearing 6205 ZZ x 30",                date:"2024-04-09", status:"Done",      notes:"" },
  { id:6, doc:"REC-006", supplier:"SteelMart",    products:"Aluminium Sheet 3mm x 10kg",          date:"2024-04-20", status:"Waiting",   notes:"Fragile" },
  { id:7, doc:"REC-007", supplier:"ElecParts",    products:"LED Driver 24V x 20",                 date:"2024-04-18", status:"Cancelled", notes:"Supplier cancelled" },
];

/* ---- State ---- */
let records    = [];
let filtered   = [];
let editingId  = null;
let deleteTarget = null;
let currentPage  = 1;
const PAGE_SIZE  = 10;

/* ---- Init ---- */
window.addEventListener("DOMContentLoaded", () => {
  load();
  buildSupplierFilter();
  applyFilters();
  bindEvents();
});

function load() {
  const raw = localStorage.getItem("inv_receipts");
  records = raw ? JSON.parse(raw) : JSON.parse(JSON.stringify(DEFAULT_RECEIPTS));
}
function save() {
  localStorage.setItem("inv_receipts", JSON.stringify(records));
}
function nextId()  { return records.length ? Math.max(...records.map(r => r.id)) + 1 : 1; }
function nextDoc() { return "REC-" + String(records.length + 1).padStart(3, "0"); }

/* ---- Bind events ---- */
function bindEvents() {
  document.getElementById("searchInput").addEventListener("input", applyFilters);
  document.getElementById("filterStatus").addEventListener("change", applyFilters);
  document.getElementById("filterSupplier").addEventListener("change", applyFilters);

  document.getElementById("logoutBtn").onclick = function () {
    alert("Logging out...");
    window.location.href = "login.html";
  };

  /* Close modals on overlay click */
  ["recModal","viewModal","deleteModal"].forEach(id => {
    document.getElementById(id).addEventListener("click", function (e) {
      if (e.target === this) this.style.display = "none";
    });
  });

  /* Escape closes modals */
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      ["recModal","viewModal","deleteModal"].forEach(id => {
        document.getElementById(id).style.display = "none";
      });
    }
  });
}

/* ---- Supplier filter ---- */
function buildSupplierFilter() {
  const sel = document.getElementById("filterSupplier");
  [...new Set(records.map(r => r.supplier))].sort().forEach(s => {
    const o = document.createElement("option"); o.value = s; o.textContent = s;
    sel.appendChild(o);
  });
}
function refreshSupplierFilter() {
  const sel = document.getElementById("filterSupplier");
  const cur = sel.value;
  while (sel.options.length > 1) sel.remove(1);
  [...new Set(records.map(r => r.supplier))].sort().forEach(s => {
    const o = document.createElement("option"); o.value = s; o.textContent = s;
    sel.appendChild(o);
  });
  sel.value = cur;
}

/* ---- Filter / Search ---- */
function applyFilters() {
  const q  = document.getElementById("searchInput").value.toLowerCase();
  const st = document.getElementById("filterStatus").value;
  const sp = document.getElementById("filterSupplier").value;

  filtered = records.filter(r => {
    const mq = !q  || [r.doc, r.supplier, r.products, r.status, r.notes].join(" ").toLowerCase().includes(q);
    const ms = !st || r.status === st;
    const mp = !sp || r.supplier === sp;
    return mq && ms && mp;
  });

  currentPage = 1;
  updateStats();
  renderTable();
}

/* ---- Stats ---- */
function updateStats() {
  document.getElementById("statTotal").textContent   = records.length;
  document.getElementById("statWaiting").textContent = records.filter(r => r.status === "Waiting").length;
  document.getElementById("statReady").textContent   = records.filter(r => r.status === "Ready").length;
  document.getElementById("statDone").textContent    = records.filter(r => r.status === "Done").length;
  document.getElementById("resultCount").textContent = `Showing ${filtered.length} of ${records.length} receipts`;
}

/* ---- Tag class ---- */
function tagClass(status) {
  const map = { Waiting:"waiting", Ready:"ready", Done:"done", Cancelled:"cancelled" };
  return map[status] || "waiting";
}

/* ---- Format date ---- */
function formatDate(d) {
  if (!d) return "—";
  return new Date(d + "T00:00:00").toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"numeric" });
}

/* ---- Render table ---- */
function renderTable() {
  const tbody = document.getElementById("recTbody");
  tbody.innerHTML = "";

  const page = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  renderPagination(filtered.length);

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;padding:30px;color:#9ca3af;">No receipts found.</td></tr>`;
    return;
  }

  page.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="doc">${esc(r.doc)}</td>
      <td>${esc(r.supplier)}</td>
      <td style="max-width:220px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(r.products)}</td>
      <td>${formatDate(r.date)}</td>
      <td><span class="tag ${tagClass(r.status)}">${r.status}</span></td>
      <td>
        <button class="act-btn btn-view"   onclick="viewRecord(${r.id})">👁 View</button>
        <button class="act-btn btn-edit"   onclick="openEditModal(${r.id})">✏️ Edit</button>
        <button class="act-btn btn-delete" onclick="confirmDelete(${r.id})">🗑</button>
      </td>`;
    tbody.appendChild(tr);
  });
}

/* ---- Pagination ---- */
function renderPagination(total) {
  const pages = Math.ceil(total / PAGE_SIZE);
  const el    = document.getElementById("pagination");
  el.innerHTML = "";
  if (pages <= 1) return;

  const prev = document.createElement("button");
  prev.className = "pg-btn"; prev.textContent = "‹ Prev";
  prev.disabled  = currentPage === 1;
  prev.onclick   = () => { currentPage--; renderTable(); };
  el.appendChild(prev);

  for (let i = 1; i <= pages; i++) {
    const btn = document.createElement("button");
    btn.className = "pg-btn" + (i === currentPage ? " active" : "");
    btn.textContent = i;
    btn.onclick = () => { currentPage = i; renderTable(); };
    el.appendChild(btn);
  }

  const next = document.createElement("button");
  next.className = "pg-btn"; next.textContent = "Next ›";
  next.disabled  = currentPage === pages;
  next.onclick   = () => { currentPage++; renderTable(); };
  el.appendChild(next);
}

/* ---- Quick filter from stat cards ---- */
function filterByAll() {
  document.getElementById("filterStatus").value   = "";
  document.getElementById("filterSupplier").value = "";
  document.getElementById("searchInput").value    = "";
  applyFilters();
}
function filterByStatus(status) {
  document.getElementById("filterStatus").value   = status;
  document.getElementById("filterSupplier").value = "";
  document.getElementById("searchInput").value    = "";
  applyFilters();
}

/* ====================================================
   ADD / EDIT MODAL
   ==================================================== */
function openAddModal() {
  editingId = null;
  document.getElementById("modalTitle").textContent = "New Receipt";
  document.getElementById("fDoc").value      = nextDoc();
  document.getElementById("fSupplier").value = "";
  document.getElementById("fDate").value     = "";
  document.getElementById("fStatus").value   = "Waiting";
  document.getElementById("fProducts").value = "";
  document.getElementById("fNotes").value    = "";
  document.getElementById("formError").textContent = "";
  document.getElementById("recModal").style.display = "flex";
}

function openEditModal(id) {
  editingId = id;
  const r = records.find(x => x.id === id);
  if (!r) return;
  document.getElementById("modalTitle").textContent = "Edit Receipt";
  document.getElementById("fDoc").value      = r.doc;
  document.getElementById("fSupplier").value = r.supplier;
  document.getElementById("fDate").value     = r.date;
  document.getElementById("fStatus").value   = r.status;
  document.getElementById("fProducts").value = r.products;
  document.getElementById("fNotes").value    = r.notes || "";
  document.getElementById("formError").textContent = "";
  document.getElementById("recModal").style.display = "flex";
}

function closeModal() {
  document.getElementById("recModal").style.display = "none";
}

function saveRecord() {
  const supplier = document.getElementById("fSupplier").value.trim();
  const date     = document.getElementById("fDate").value;
  const status   = document.getElementById("fStatus").value;
  const products = document.getElementById("fProducts").value.trim();
  const notes    = document.getElementById("fNotes").value.trim();
  const errEl    = document.getElementById("formError");

  if (!supplier) { errEl.textContent = "Supplier name is required."; return; }
  if (!date)     { errEl.textContent = "Expected date is required."; return; }

  if (editingId) {
    const idx = records.findIndex(r => r.id === editingId);
    records[idx] = { ...records[idx], supplier, date, status, products, notes };
    toast("Receipt updated successfully!", "success");
  } else {
    records.push({ id: nextId(), doc: nextDoc(), supplier, date, status, products, notes });
    toast("Receipt created successfully!", "success");
  }

  save();
  closeModal();
  refreshSupplierFilter();
  applyFilters();
}

/* ====================================================
   VIEW DETAIL MODAL
   ==================================================== */
function viewRecord(id) {
  const r = records.find(x => x.id === id);
  if (!r) return;
  document.getElementById("viewModalBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><label>Document No.</label><span class="doc">${esc(r.doc)}</span></div>
      <div class="detail-item"><label>Supplier</label><span>${esc(r.supplier)}</span></div>
      <div class="detail-item"><label>Expected Date</label><span>${formatDate(r.date)}</span></div>
      <div class="detail-item"><label>Status</label><span class="tag ${tagClass(r.status)}">${r.status}</span></div>
      <div class="detail-item full-width"><label>Products / Items</label><span>${esc(r.products) || "—"}</span></div>
      <div class="detail-item full-width"><label>Notes</label><span>${esc(r.notes) || "—"}</span></div>
    </div>`;
  document.getElementById("viewEditBtn").onclick = () => { closeViewModal(); openEditModal(id); };
  document.getElementById("viewModal").style.display = "flex";
}

function closeViewModal() {
  document.getElementById("viewModal").style.display = "none";
}

/* ====================================================
   DELETE
   ==================================================== */
function confirmDelete(id) {
  deleteTarget = id;
  const r = records.find(x => x.id === id);
  document.getElementById("deleteMsg").textContent =
    `Are you sure you want to delete receipt "${r ? r.doc : ""}"? This cannot be undone.`;
  document.getElementById("confirmDeleteBtn").onclick = doDelete;
  document.getElementById("deleteModal").style.display = "flex";
}

function closeDeleteModal() {
  document.getElementById("deleteModal").style.display = "none";
}

function doDelete() {
  records = records.filter(r => r.id !== deleteTarget);
  save();
  refreshSupplierFilter();
  applyFilters();
  closeDeleteModal();
  toast("Receipt deleted.", "success");
}

/* ====================================================
   UTILITIES
   ==================================================== */
function esc(str) {
  return String(str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

function toast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className   = "toast show" + (type ? " " + type : "");
  setTimeout(() => el.classList.remove("show"), 3000);
}
