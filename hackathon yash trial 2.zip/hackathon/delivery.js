/* ============================================================
   delivery.js  –  Full CRUD + search / filter / paging
   ============================================================ */

/* ---- Default seed data ---- */
const DEFAULT_DELIVERIES = [
  { id:1, doc:"DEL-001", customer:"Home Goods",    products:"Finished Gear A x 10",          date:"2024-04-09", status:"Ready",     address:"123 MG Road, Ahmedabad",    contact:"+91 98765 43210", notes:"" },
  { id:2, doc:"DEL-002", customer:"BuildMart",     products:"Steel Bolt M8 x 500",            date:"2024-04-11", status:"Waiting",   address:"45 Ring Road, Surat",       contact:"+91 99887 76655", notes:"Fragile – handle with care" },
  { id:3, doc:"DEL-003", customer:"TechZone",      products:"LED Driver 24V x 5",             date:"2024-04-07", status:"Done",      address:"78 IT Park, Gandhinagar",   contact:"",                notes:"Delivered on time" },
  { id:4, doc:"DEL-004", customer:"PackPro",       products:"Packaging Box L x 100",          date:"2024-04-14", status:"Waiting",   address:"22 GIDC, Vadodara",         contact:"+91 90011 22334", notes:"" },
  { id:5, doc:"DEL-005", customer:"MegaStore",     products:"Hydraulic Oil 5W x 10ltr",       date:"2024-04-16", status:"Ready",     address:"88 NH-8, Rajkot",           contact:"+91 91234 56789", notes:"Call before delivery" },
  { id:6, doc:"DEL-006", customer:"Home Goods",    products:"Aluminium Sheet 3mm x 5kg",      date:"2024-04-18", status:"Waiting",   address:"123 MG Road, Ahmedabad",    contact:"+91 98765 43210", notes:"" },
  { id:7, doc:"DEL-007", customer:"BuildMart",     products:"Bearing 6205 ZZ x 20",           date:"2024-04-05", status:"Done",      address:"45 Ring Road, Surat",       contact:"+91 99887 76655", notes:"" },
  { id:8, doc:"DEL-008", customer:"QuickFix Ltd",  products:"Spare Parts Kit x 3",            date:"2024-04-20", status:"Cancelled", address:"10 Opp. Civil, Anand",      contact:"+91 87654 32109", notes:"Customer cancelled order" },
];

/* ---- State ---- */
let records     = [];
let filtered    = [];
let editingId   = null;
let deleteTarget = null;
let currentPage  = 1;
const PAGE_SIZE  = 10;

/* ---- Init ---- */
window.addEventListener("DOMContentLoaded", () => {
  load();
  buildCustomerFilter();
  applyFilters();
  bindEvents();
});

function load() {
  const raw = localStorage.getItem("inv_deliveries");
  records = raw ? JSON.parse(raw) : JSON.parse(JSON.stringify(DEFAULT_DELIVERIES));
}
function save() {
  localStorage.setItem("inv_deliveries", JSON.stringify(records));
}
function nextId()  { return records.length ? Math.max(...records.map(r => r.id)) + 1 : 1; }
function nextDoc() { return "DEL-" + String(records.length + 1).padStart(3, "0"); }

/* ---- Bind events ---- */
function bindEvents() {
  document.getElementById("searchInput").addEventListener("input", applyFilters);
  document.getElementById("filterStatus").addEventListener("change", applyFilters);
  document.getElementById("filterCustomer").addEventListener("change", applyFilters);

  document.getElementById("logoutBtn").onclick = function () {
    alert("Logging out...");
    window.location.href = "login.html";
  };

  /* Close modals on overlay click */
  ["delModal","viewModal","deleteModal"].forEach(id => {
    document.getElementById(id).addEventListener("click", function (e) {
      if (e.target === this) this.style.display = "none";
    });
  });

  /* Escape closes modals */
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      ["delModal","viewModal","deleteModal"].forEach(id => {
        document.getElementById(id).style.display = "none";
      });
    }
  });
}

/* ---- Customer filter ---- */
function buildCustomerFilter() {
  const sel = document.getElementById("filterCustomer");
  [...new Set(records.map(r => r.customer))].sort().forEach(c => {
    const o = document.createElement("option"); o.value = c; o.textContent = c;
    sel.appendChild(o);
  });
}
function refreshCustomerFilter() {
  const sel = document.getElementById("filterCustomer");
  const cur = sel.value;
  while (sel.options.length > 1) sel.remove(1);
  [...new Set(records.map(r => r.customer))].sort().forEach(c => {
    const o = document.createElement("option"); o.value = c; o.textContent = c;
    sel.appendChild(o);
  });
  sel.value = cur;
}

/* ---- Filter / Search ---- */
function applyFilters() {
  const q  = document.getElementById("searchInput").value.toLowerCase();
  const st = document.getElementById("filterStatus").value;
  const cu = document.getElementById("filterCustomer").value;

  filtered = records.filter(r => {
    const mq = !q  || [r.doc, r.customer, r.products, r.status, r.address, r.notes].join(" ").toLowerCase().includes(q);
    const ms = !st || r.status === st;
    const mc = !cu || r.customer === cu;
    return mq && ms && mc;
  });

  currentPage = 1;
  updateStats();
  renderTable();
}

/* ---- Stats ---- */
function updateStats() {
  document.getElementById("statTotal").textContent   = records.length;
  document.getElementById("statWaiting").textContent = records.filter(r => r.status === "Waiting").length;
  document.getElementById("statReady").textContent   = records.filter(r => r.status === "Ready").length;
  document.getElementById("statDone").textContent    = records.filter(r => r.status === "Done").length;
  document.getElementById("resultCount").textContent = `Showing ${filtered.length} of ${records.length} deliveries`;
}

/* ---- Tag class ---- */
function tagClass(status) {
  const map = { Waiting:"waiting", Ready:"ready", Done:"done", Cancelled:"cancelled" };
  return map[status] || "waiting";
}

/* ---- Format date ---- */
function formatDate(d) {
  if (!d) return "—";
  return new Date(d + "T00:00:00").toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"numeric" });
}

/* ---- Render table ---- */
function renderTable() {
  const tbody = document.getElementById("delTbody");
  tbody.innerHTML = "";

  const page = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  renderPagination(filtered.length);

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:30px;color:#9ca3af;">No deliveries found.</td></tr>`;
    return;
  }

  page.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="doc">${esc(r.doc)}</td>
      <td>${esc(r.customer)}</td>
      <td style="max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(r.products)}</td>
      <td>${formatDate(r.date)}</td>
      <td style="max-width:160px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#6b7280;font-size:13px;">${esc(r.address) || "—"}</td>
      <td><span class="tag ${tagClass(r.status)}">${r.status}</span></td>
      <td>
        <button class="act-btn btn-view"   onclick="viewRecord(${r.id})">👁 View</button>
        <button class="act-btn btn-edit"   onclick="openEditModal(${r.id})">✏️ Edit</button>
        <button class="act-btn btn-delete" onclick="confirmDelete(${r.id})">🗑</button>
      </td>`;
    tbody.appendChild(tr);
  });
}

/* ---- Pagination ---- */
function renderPagination(total) {
  const pages = Math.ceil(total / PAGE_SIZE);
  const el    = document.getElementById("pagination");
  el.innerHTML = "";
  if (pages <= 1) return;

  const prev = document.createElement("button");
  prev.className = "pg-btn"; prev.textContent = "‹ Prev";
  prev.disabled  = currentPage === 1;
  prev.onclick   = () => { currentPage--; renderTable(); };
  el.appendChild(prev);

  for (let i = 1; i <= pages; i++) {
    const btn = document.createElement("button");
    btn.className = "pg-btn" + (i === currentPage ? " active" : "");
    btn.textContent = i;
    btn.onclick = () => { currentPage = i; renderTable(); };
    el.appendChild(btn);
  }

  const next = document.createElement("button");
  next.className = "pg-btn"; next.textContent = "Next ›";
  next.disabled  = currentPage === pages;
  next.onclick   = () => { currentPage++; renderTable(); };
  el.appendChild(next);
}

/* ---- Quick filter from stat cards ---- */
function filterByAll() {
  document.getElementById("filterStatus").value   = "";
  document.getElementById("filterCustomer").value = "";
  document.getElementById("searchInput").value    = "";
  applyFilters();
}
function filterByStatus(status) {
  document.getElementById("filterStatus").value   = status;
  document.getElementById("filterCustomer").value = "";
  document.getElementById("searchInput").value    = "";
  applyFilters();
}

/* ====================================================
   ADD / EDIT MODAL
   ==================================================== */
function openAddModal() {
  editingId = null;
  document.getElementById("modalTitle").textContent = "New Delivery Order";
  document.getElementById("fDoc").value      = nextDoc();
  document.getElementById("fCustomer").value = "";
  document.getElementById("fDate").value     = "";
  document.getElementById("fStatus").value   = "Waiting";
  document.getElementById("fAddress").value  = "";
  document.getElementById("fContact").value  = "";
  document.getElementById("fProducts").value = "";
  document.getElementById("fNotes").value    = "";
  document.getElementById("formError").textContent = "";
  document.getElementById("delModal").style.display = "flex";
}

function openEditModal(id) {
  editingId = id;
  const r = records.find(x => x.id === id);
  if (!r) return;
  document.getElementById("modalTitle").textContent = "Edit Delivery Order";
  document.getElementById("fDoc").value      = r.doc;
  document.getElementById("fCustomer").value = r.customer;
  document.getElementById("fDate").value     = r.date;
  document.getElementById("fStatus").value   = r.status;
  document.getElementById("fAddress").value  = r.address  || "";
  document.getElementById("fContact").value  = r.contact  || "";
  document.getElementById("fProducts").value = r.products;
  document.getElementById("fNotes").value    = r.notes    || "";
  document.getElementById("formError").textContent = "";
  document.getElementById("delModal").style.display = "flex";
}

function closeModal() {
  document.getElementById("delModal").style.display = "none";
}

function saveRecord() {
  const customer = document.getElementById("fCustomer").value.trim();
  const date     = document.getElementById("fDate").value;
  const status   = document.getElementById("fStatus").value;
  const address  = document.getElementById("fAddress").value.trim();
  const contact  = document.getElementById("fContact").value.trim();
  const products = document.getElementById("fProducts").value.trim();
  const notes    = document.getElementById("fNotes").value.trim();
  const errEl    = document.getElementById("formError");

  if (!customer) { errEl.textContent = "Customer name is required."; return; }
  if (!date)     { errEl.textContent = "Delivery date is required."; return; }

  if (editingId) {
    const idx = records.findIndex(r => r.id === editingId);
    records[idx] = { ...records[idx], customer, date, status, address, contact, products, notes };
    toast("Delivery updated successfully!", "success");
  } else {
    records.push({ id: nextId(), doc: nextDoc(), customer, date, status, address, contact, products, notes });
    toast("Delivery created successfully!", "success");
  }

  save();
  closeModal();
  refreshCustomerFilter();
  applyFilters();
}

/* ====================================================
   VIEW DETAIL MODAL
   ==================================================== */
function viewRecord(id) {
  const r = records.find(x => x.id === id);
  if (!r) return;
  document.getElementById("viewModalBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><label>Document No.</label><span class="doc">${esc(r.doc)}</span></div>
      <div class="detail-item"><label>Customer</label><span>${esc(r.customer)}</span></div>
      <div class="detail-item"><label>Delivery Date</label><span>${formatDate(r.date)}</span></div>
      <div class="detail-item"><label>Status</label><span class="tag ${tagClass(r.status)}">${r.status}</span></div>
      <div class="detail-item"><label>Destination Address</label><span>${esc(r.address) || "—"}</span></div>
      <div class="detail-item"><label>Contact No.</label><span>${esc(r.contact) || "—"}</span></div>
      <div class="detail-item full-width"><label>Products / Items</label><span>${esc(r.products) || "—"}</span></div>
      <div class="detail-item full-width"><label>Notes</label><span>${esc(r.notes) || "—"}</span></div>
    </div>`;
  document.getElementById("viewEditBtn").onclick = () => { closeViewModal(); openEditModal(id); };
  document.getElementById("viewModal").style.display = "flex";
}

function closeViewModal() {
  document.getElementById("viewModal").style.display = "none";
}

/* ====================================================
   DELETE
   ==================================================== */
function confirmDelete(id) {
  deleteTarget = id;
  const r = records.find(x => x.id === id);
  document.getElementById("deleteMsg").textContent =
    `Are you sure you want to delete delivery "${r ? r.doc : ""}"? This cannot be undone.`;
  document.getElementById("confirmDeleteBtn").onclick = doDelete;
  document.getElementById("deleteModal").style.display = "flex";
}

function closeDeleteModal() {
  document.getElementById("deleteModal").style.display = "none";
}

function doDelete() {
  records = records.filter(r => r.id !== deleteTarget);
  save();
  refreshCustomerFilter();
  applyFilters();
  closeDeleteModal();
  toast("Delivery deleted.", "success");
}

/* ====================================================
   UTILITIES
   ==================================================== */
function esc(str) {
  return String(str || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}

function toast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className   = "toast show" + (type ? " " + type : "");
  setTimeout(() => el.classList.remove("show"), 3000);
}
