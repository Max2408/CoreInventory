/* ============================================================
   products.js  –  Full CRUD + search / filter / sort / paging
   ============================================================ */

/* ---- Default seed data ---- */
const DEFAULT_PRODUCTS = [
  { id:1,  name:"Steel Bolt M8",       sku:"STL-M8-001",  category:"Raw Materials",  qty:340, reorder:50,  price:2.50,  unit:"pcs",  location:"Aisle A – Rack 1", description:"M8 hex head bolt, galvanised." },
  { id:2,  name:"Copper Wire 2.5mm",   sku:"ELC-CW-025",  category:"Electronics",    qty:18,  reorder:30,  price:120.00, unit:"m",   location:"Aisle C – Rack 2", description:"Single-core copper wire." },
  { id:3,  name:"Packaging Box L",     sku:"PKG-BOX-L",   category:"Packaging",      qty:0,   reorder:20,  price:15.00, unit:"pcs",  location:"Aisle D – Rack 5", description:"Large export carton." },
  { id:4,  name:"Hydraulic Oil 5W",    sku:"CSM-HOL-5W",  category:"Consumables",    qty:62,  reorder:10,  price:850.00,unit:"ltr",  location:"Aisle B – Rack 3", description:"ISO VG 46 hydraulic oil." },
  { id:5,  name:"Bearing 6205 ZZ",     sku:"SPS-BRG-205", category:"Spare Parts",    qty:9,   reorder:15,  price:210.00,unit:"pcs",  location:"Aisle B – Rack 7", description:"Deep groove ball bearing." },
  { id:6,  name:"Finished Gear A",     sku:"FG-GEA-001",  category:"Finished Goods", qty:120, reorder:25,  price:1200.00,unit:"pcs", location:"Aisle E – Rack 1", description:"Finished spur gear, module 2." },
  { id:7,  name:"Aluminium Sheet 3mm", sku:"RM-ALS-3MM",  category:"Raw Materials",  qty:45,  reorder:10,  price:680.00,unit:"kg",   location:"Aisle A – Rack 4", description:"3mm aluminium alloy 6061." },
  { id:8,  name:"LED Driver 24V",      sku:"ELC-LED-24V", category:"Electronics",    qty:0,   reorder:5,   price:320.00,unit:"pcs",  location:"Aisle C – Rack 1", description:"24V constant-voltage LED driver." },
];

/* ---- State ---- */
let products    = [];
let filtered    = [];
let editingId   = null;
let deleteTarget= null;
let sortCol     = "";
let sortDir     = "asc";
let currentPage = 1;
const PAGE_SIZE = 10;
let viewMode    = "table";

/* ---- Init ---- */
window.addEventListener("DOMContentLoaded", () => {
  load();
  renderCategoryFilter();

  // handle ?filter=low coming from dashboard "View Low Stock" button
  const params = new URLSearchParams(window.location.search);
  if (params.get("filter") === "low") {
    document.getElementById("filterStatus").value = "Low Stock";
  }

  applyFilters();
  bindEvents();
});

function load() {
  const raw = localStorage.getItem("inv_products");
  products = raw ? JSON.parse(raw) : JSON.parse(JSON.stringify(DEFAULT_PRODUCTS));
}
function save() {
  localStorage.setItem("inv_products", JSON.stringify(products));
}
function nextId() {
  return products.length ? Math.max(...products.map(p=>p.id)) + 1 : 1;
}

/* ---- Events ---- */
function bindEvents() {
  document.getElementById("searchInput").addEventListener("input", applyFilters);
  document.getElementById("filterCategory").addEventListener("change", applyFilters);
  document.getElementById("filterStatus").addEventListener("change", applyFilters);
  document.getElementById("viewMode").addEventListener("change", e => {
    viewMode = e.target.value;
    renderView();
  });

  document.querySelectorAll("th.sortable").forEach(th => {
    th.addEventListener("click", () => {
      const col = th.dataset.col;
      if (sortCol === col) sortDir = sortDir === "asc" ? "desc" : "asc";
      else { sortCol = col; sortDir = "asc"; }
      document.querySelectorAll("th.sortable").forEach(t => t.classList.remove("asc","desc"));
      th.classList.add(sortDir);
      applyFilters();
    });
  });

  document.getElementById("logoutBtn").onclick = () => {
    alert("Logging out…");
    window.location.href = "login.html";
  };
}

/* ---- Filtering / Sorting ---- */
function applyFilters() {
  const q    = document.getElementById("searchInput").value.toLowerCase();
  const cat  = document.getElementById("filterCategory").value;
  const stat = document.getElementById("filterStatus").value;

  filtered = products.filter(p => {
    const matchQ   = !q   || [p.name,p.sku,p.category,p.location,p.description].join(" ").toLowerCase().includes(q);
    const matchCat = !cat || p.category === cat;
    const matchSt  = !stat|| getStatus(p) === stat;
    return matchQ && matchCat && matchSt;
  });

  if (sortCol) {
    filtered.sort((a,b) => {
      let va = a[sortCol], vb = b[sortCol];
      if (typeof va === "string") { va=va.toLowerCase(); vb=vb.toLowerCase(); }
      return sortDir === "asc" ? (va>vb?1:va<vb?-1:0) : (va<vb?1:va>vb?-1:0);
    });
  }

  currentPage = 1;
  updateStats();
  renderView();
}

function getStatus(p) {
  if (p.qty === 0) return "Out of Stock";
  if (p.reorder > 0 && p.qty <= p.reorder) return "Low Stock";
  return "In Stock";
}
function getTagClass(status) {
  if (status === "Out of Stock") return "out-stock";
  if (status === "Low Stock")    return "low-stock";
  return "in-stock";
}

/* ---- Stats ---- */
function updateStats() {
  document.getElementById("statTotal").textContent   = products.length;
  document.getElementById("statInStock").textContent = products.filter(p=>getStatus(p)==="In Stock").length;
  document.getElementById("statLow").textContent     = products.filter(p=>getStatus(p)==="Low Stock").length;
  document.getElementById("statOut").textContent     = products.filter(p=>getStatus(p)==="Out of Stock").length;
  document.getElementById("resultCount").textContent = `Showing ${filtered.length} of ${products.length} products`;
}

/* ---- Category filter options ---- */
function renderCategoryFilter() {
  const cats = [...new Set(products.map(p=>p.category))].sort();
  const sel  = document.getElementById("filterCategory");
  cats.forEach(c => {
    const o = document.createElement("option"); o.value = c; o.textContent = c;
    sel.appendChild(o);
  });
}
function refreshCategoryFilter() {
  const sel = document.getElementById("filterCategory");
  const cur = sel.value;
  while (sel.options.length > 1) sel.remove(1);
  const cats = [...new Set(products.map(p=>p.category))].sort();
  cats.forEach(c => {
    const o = document.createElement("option"); o.value = c; o.textContent = c;
    sel.appendChild(o);
  });
  sel.value = cur;
}

/* ====================================================
   RENDER
   ==================================================== */
function renderView() {
  if (viewMode === "grid") {
    document.getElementById("tableView").style.display = "none";
    document.getElementById("gridView").style.display  = "block";
    renderGrid();
  } else {
    document.getElementById("tableView").style.display = "block";
    document.getElementById("gridView").style.display  = "none";
    renderTable();
  }
}

/* ---- Table ---- */
function renderTable() {
  const tbody = document.getElementById("productTbody");
  tbody.innerHTML = "";

  const page = paginate(filtered, currentPage, PAGE_SIZE);
  renderPagination("pagination", filtered.length);

  if (!page.length) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center;padding:30px;color:#9ca3af;">No products found.</td></tr>`;
    return;
  }

  page.forEach(p => {
    const status = getStatus(p);
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><input type="checkbox" class="row-check" data-id="${p.id}" onchange="onRowCheck()"></td>
      <td class="doc">${esc(p.name)}</td>
      <td>${esc(p.sku)}</td>
      <td>${esc(p.category)}</td>
      <td><b>${p.qty}</b> ${esc(p.unit)}</td>
      <td>${p.reorder}</td>
      <td>₹${(+p.price).toFixed(2)}</td>
      <td><span class="tag ${getTagClass(status)}">${status}</span></td>
      <td>
        <button class="act-btn btn-view"   onclick="viewProduct(${p.id})">👁 View</button>
        <button class="act-btn btn-edit"   onclick="openEditModal(${p.id})">✏️ Edit</button>
        <button class="act-btn btn-delete" onclick="confirmDelete(${p.id})">🗑</button>
      </td>`;
    tbody.appendChild(tr);
  });
}

/* ---- Grid ---- */
function renderGrid() {
  const grid = document.getElementById("productGrid");
  grid.innerHTML = "";

  const page = paginate(filtered, currentPage, PAGE_SIZE);
  renderPagination("paginationGrid", filtered.length);

  if (!page.length) {
    grid.innerHTML = `<p style="color:#9ca3af;grid-column:1/-1;text-align:center;padding:40px 0;">No products found.</p>`;
    return;
  }

  page.forEach(p => {
    const status = getStatus(p);
    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <div class="pc-sku">${esc(p.sku)}</div>
      <div class="pc-name">${esc(p.name)}</div>
      <div class="pc-cat">${esc(p.category)} · ${esc(p.unit)}</div>
      <div class="pc-qty">${p.qty}<span>in stock</span></div>
      <div class="pc-footer">
        <span class="tag ${getTagClass(status)}">${status}</span>
        <div class="pc-actions">
          <button class="act-btn btn-view"   onclick="viewProduct(${p.id})">👁</button>
          <button class="act-btn btn-edit"   onclick="openEditModal(${p.id})">✏️</button>
          <button class="act-btn btn-delete" onclick="confirmDelete(${p.id})">🗑</button>
        </div>
      </div>`;
    grid.appendChild(card);
  });
}

/* ---- Pagination ---- */
function paginate(arr, page, size) {
  return arr.slice((page-1)*size, page*size);
}
function renderPagination(containerId, total) {
  const pages = Math.ceil(total / PAGE_SIZE);
  const el    = document.getElementById(containerId);
  el.innerHTML = "";
  if (pages <= 1) return;

  const prev = document.createElement("button");
  prev.className = "pg-btn"; prev.textContent = "‹ Prev";
  prev.disabled  = currentPage === 1;
  prev.onclick   = () => { currentPage--; renderView(); };
  el.appendChild(prev);

  for (let i = 1; i <= pages; i++) {
    const btn = document.createElement("button");
    btn.className = "pg-btn" + (i === currentPage ? " active" : "");
    btn.textContent = i;
    btn.onclick = () => { currentPage = i; renderView(); };
    el.appendChild(btn);
  }

  const next = document.createElement("button");
  next.className = "pg-btn"; next.textContent = "Next ›";
  next.disabled  = currentPage === pages;
  next.onclick   = () => { currentPage++; renderView(); };
  el.appendChild(next);
}

/* ====================================================
   ADD / EDIT MODAL
   ==================================================== */
function openAddModal() {
  editingId = null;
  document.getElementById("modalTitle").textContent = "Add Product";
  clearForm();
  document.getElementById("productModal").style.display = "flex";
}

function openEditModal(id) {
  editingId = id;
  const p = products.find(x=>x.id===id);
  if (!p) return;
  document.getElementById("modalTitle").textContent = "Edit Product";
  document.getElementById("fName").value      = p.name;
  document.getElementById("fSKU").value       = p.sku;
  document.getElementById("fCategory").value  = p.category;
  document.getElementById("fQty").value       = p.qty;
  document.getElementById("fReorder").value   = p.reorder;
  document.getElementById("fPrice").value     = p.price;
  document.getElementById("fUnit").value      = p.unit;
  document.getElementById("fLocation").value  = p.location;
  document.getElementById("fDesc").value      = p.description || "";
  document.getElementById("formError").textContent = "";
  document.getElementById("productModal").style.display = "flex";
}

function closeModal() {
  document.getElementById("productModal").style.display = "none";
}

function clearForm() {
  ["fName","fSKU","fLocation","fDesc"].forEach(id=>document.getElementById(id).value="");
  ["fQty","fReorder","fPrice"].forEach(id=>document.getElementById(id).value="");
  document.getElementById("fCategory").value = "";
  document.getElementById("fUnit").value     = "pcs";
  document.getElementById("formError").textContent = "";
}

function saveProduct() {
  const name        = document.getElementById("fName").value.trim();
  const sku         = document.getElementById("fSKU").value.trim();
  const category    = document.getElementById("fCategory").value;
  const qty         = parseInt(document.getElementById("fQty").value);
  const reorder     = parseInt(document.getElementById("fReorder").value) || 0;
  const price       = parseFloat(document.getElementById("fPrice").value) || 0;
  const unit        = document.getElementById("fUnit").value;
  const location    = document.getElementById("fLocation").value.trim();
  const description = document.getElementById("fDesc").value.trim();
  const errEl       = document.getElementById("formError");

  if (!name)     { errEl.textContent = "Product name is required."; return; }
  if (!sku)      { errEl.textContent = "SKU is required."; return; }
  if (!category) { errEl.textContent = "Please select a category."; return; }
  if (isNaN(qty) || qty < 0) { errEl.textContent = "Enter a valid quantity."; return; }

  const dupSKU = products.find(p => p.sku === sku && p.id !== editingId);
  if (dupSKU) { errEl.textContent = `SKU "${sku}" already exists.`; return; }

  if (editingId) {
    const idx = products.findIndex(p=>p.id===editingId);
    products[idx] = { ...products[idx], name, sku, category, qty, reorder, price, unit, location, description };
    toast("Product updated successfully!", "success");
  } else {
    products.push({ id: nextId(), name, sku, category, qty, reorder, price, unit, location, description });
    toast("Product added successfully!", "success");
  }

  save();
  closeModal();
  refreshCategoryFilter();
  applyFilters();
}

/* ====================================================
   VIEW DETAIL MODAL
   ==================================================== */
function viewProduct(id) {
  const p = products.find(x=>x.id===id);
  if (!p) return;
  const status = getStatus(p);
  document.getElementById("viewModalBody").innerHTML = `
    <div class="detail-grid">
      <div class="detail-item"><label>Product Name</label><span>${esc(p.name)}</span></div>
      <div class="detail-item"><label>SKU</label><span>${esc(p.sku)}</span></div>
      <div class="detail-item"><label>Category</label><span>${esc(p.category)}</span></div>
      <div class="detail-item"><label>Unit</label><span>${esc(p.unit)}</span></div>
      <div class="detail-item"><label>Quantity in Stock</label><span><b style="font-size:22px;">${p.qty}</b> ${esc(p.unit)}</span></div>
      <div class="detail-item"><label>Reorder Point</label><span>${p.reorder} ${esc(p.unit)}</span></div>
      <div class="detail-item"><label>Unit Price</label><span>₹${(+p.price).toFixed(2)}</span></div>
      <div class="detail-item"><label>Status</label><span class="tag ${getTagClass(status)}">${status}</span></div>
      <div class="detail-item full-width"><label>Warehouse Location</label><span>${esc(p.location)||"—"}</span></div>
      <div class="detail-item full-width"><label>Description</label><span>${esc(p.description)||"—"}</span></div>
    </div>`;
  document.getElementById("viewEditBtn").onclick = () => { closeViewModal(); openEditModal(id); };
  document.getElementById("viewModal").style.display = "flex";
}
function closeViewModal() { document.getElementById("viewModal").style.display = "none"; }

/* ====================================================
   DELETE
   ==================================================== */
function confirmDelete(id) {
  deleteTarget = id;
  const p = products.find(x=>x.id===id);
  document.getElementById("deleteMsg").textContent =
    `Are you sure you want to delete "${p ? p.name : "this product"}"? This cannot be undone.`;
  document.getElementById("confirmDeleteBtn").onclick = () => doDelete();
  document.getElementById("deleteModal").style.display = "flex";
}
function closeDeleteModal() { document.getElementById("deleteModal").style.display = "none"; }

function doDelete() {
  if (Array.isArray(deleteTarget)) {
    products = products.filter(p => !deleteTarget.includes(p.id));
    toast(`${deleteTarget.length} products deleted.`, "success");
  } else {
    products = products.filter(p => p.id !== deleteTarget);
    toast("Product deleted.", "success");
  }
  save(); refreshCategoryFilter(); applyFilters();
  closeDeleteModal();
  clearSelection();
}

/* ====================================================
   BULK ACTIONS
   ==================================================== */
function onRowCheck() {
  const checked = document.querySelectorAll(".row-check:checked");
  const bar     = document.getElementById("bulkBar");
  document.getElementById("selectAll").checked =
    checked.length === document.querySelectorAll(".row-check").length && checked.length > 0;

  if (checked.length > 0) {
    bar.style.display = "flex";
    document.getElementById("bulkCount").textContent = `${checked.length} selected`;
  } else {
    bar.style.display = "none";
  }
}
function toggleSelectAll(master) {
  document.querySelectorAll(".row-check").forEach(cb => { cb.checked = master.checked; });
  onRowCheck();
}
function clearSelection() {
  document.querySelectorAll(".row-check").forEach(cb => cb.checked = false);
  const sa = document.getElementById("selectAll");
  if (sa) sa.checked = false;
  document.getElementById("bulkBar").style.display = "none";
}
function getSelectedIds() {
  return [...document.querySelectorAll(".row-check:checked")].map(cb => +cb.dataset.id);
}
function bulkDelete() {
  const ids = getSelectedIds();
  if (!ids.length) return;
  deleteTarget = ids;
  document.getElementById("deleteMsg").textContent =
    `Delete ${ids.length} selected product(s)? This cannot be undone.`;
  document.getElementById("confirmDeleteBtn").onclick = () => doDelete();
  document.getElementById("deleteModal").style.display = "flex";
}
function bulkUpdateCategory() {
  const ids = getSelectedIds();
  if (!ids.length) return;
  const cats = ["Raw Materials","Finished Goods","Packaging","Spare Parts","Electronics","Consumables","Other"];
  const choice = prompt("Enter new category:\n" + cats.join(", "));
  if (!choice || !cats.includes(choice)) { toast("Invalid category.", "error"); return; }
  ids.forEach(id => { const p = products.find(x=>x.id===id); if(p) p.category = choice; });
  save(); refreshCategoryFilter(); applyFilters(); clearSelection();
  toast(`Updated category for ${ids.length} product(s).`, "success");
}

/* ====================================================
   STAT CARD QUICK FILTERS
   ==================================================== */
function filterByAll() {
  document.getElementById("filterStatus").value   = "";
  document.getElementById("filterCategory").value = "";
  document.getElementById("searchInput").value    = "";
  applyFilters();
}
function filterByStatus(status) {
  document.getElementById("filterStatus").value   = status;
  document.getElementById("filterCategory").value = "";
  document.getElementById("searchInput").value    = "";
  applyFilters();
}

/* ====================================================
   CSV EXPORT
   ==================================================== */
function exportCSV() {
  const rows = [["ID","Name","SKU","Category","Qty","Reorder","Price","Unit","Location","Description"]];
  products.forEach(p => rows.push([p.id, p.name, p.sku, p.category, p.qty, p.reorder, p.price, p.unit, p.location, p.description||""]));
  const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
  downloadFile("products_export.csv", "text/csv", csv);
  toast("Exported successfully!", "success");
}

/* ====================================================
   CSV IMPORT
   ==================================================== */
function openImportModal()  { document.getElementById("importModal").style.display = "flex"; document.getElementById("importError").textContent=""; document.getElementById("csvFile").value=""; }
function closeImportModal() { document.getElementById("importModal").style.display = "none"; }

function importCSV() {
  const file  = document.getElementById("csvFile").files[0];
  const errEl = document.getElementById("importError");
  if (!file) { errEl.textContent = "Please select a CSV file."; return; }

  const reader = new FileReader();
  reader.onload = e => {
    const lines  = e.target.result.split(/\r?\n/).filter(l=>l.trim());
    const header = lines[0].split(",").map(h=>h.replace(/"/g,"").trim().toLowerCase());
    const required = ["name","sku","category","qty"];
    const missing  = required.filter(f=>!header.includes(f));
    if (missing.length) { errEl.textContent = `Missing columns: ${missing.join(", ")}`; return; }

    let added = 0, skipped = 0;
    for (let i = 1; i < lines.length; i++) {
      const vals = parseCSVLine(lines[i]);
      const row  = {};
      header.forEach((h,j) => row[h] = vals[j] ? vals[j].replace(/^"|"$/g,"").trim() : "");
      if (!row.name || !row.sku || !row.category) { skipped++; continue; }
      if (products.find(p=>p.sku===row.sku)) { skipped++; continue; }
      products.push({
        id: nextId(), name:row.name, sku:row.sku, category:row.category,
        qty:parseInt(row.qty)||0, reorder:parseInt(row.reorder)||0,
        price:parseFloat(row.price)||0, unit:row.unit||"pcs",
        location:row.location||"", description:row.description||""
      });
      added++;
    }
    save(); refreshCategoryFilter(); applyFilters(); closeImportModal();
    toast(`Imported ${added} product(s). ${skipped} skipped.`, "success");
  };
  reader.readAsText(file);
}

function parseCSVLine(line) {
  const result = []; let cur = ""; let inQ = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') { inQ = !inQ; }
    else if (c === "," && !inQ) { result.push(cur); cur = ""; }
    else cur += c;
  }
  result.push(cur);
  return result;
}

function downloadTemplate() {
  const csv = `"name","sku","category","qty","reorder","price","unit","location","description"\n"Sample Product","SKU-001","Raw Materials","100","10","50.00","pcs","Aisle A – Rack 1","Sample description"`;
  downloadFile("products_template.csv", "text/csv", csv);
  return false;
}

/* ====================================================
   UTILITIES
   ==================================================== */
function esc(str) {
  return String(str||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function downloadFile(filename, mime, content) {
  const blob = new Blob([content], { type: mime });
  const a    = document.createElement("a");
  a.href     = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}
function toast(msg, type = "") {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.className   = "toast show" + (type ? " " + type : "");
  setTimeout(() => el.classList.remove("show"), 3000);
}

/* Close modals on overlay click */
["productModal","viewModal","deleteModal","importModal"].forEach(id => {
  document.getElementById(id).addEventListener("click", function(e){
    if (e.target === this) this.style.display = "none";
  });
});

/* Escape key closes modals */
document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    ["productModal","viewModal","deleteModal","importModal"].forEach(id => {
      document.getElementById(id).style.display = "none";
    });
  }
});
